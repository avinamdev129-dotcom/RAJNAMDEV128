
export enum LevelType {
  FLAGS = 'Flags',
  SCIENCE = 'Science',
  HISTORY = 'History',
  WORLD_GEOGRAPHY = 'World Geography',
  DAILY_CHALLENGE = 'Daily Challenge',
}

export interface QuizRound {
  question: string;
  correctAnswer: string;
  options: string[];
  flagEmoji?: string;
}

export enum GameState {
  SELECT_LEVEL_TYPE,
  SELECT_DIFFICULTY,
  LOADING,
  PLAYING,
  ROUND_OVER,
  GAME_OVER,
  ERROR,
  VIEW_PROFILE,
  ONBOARDING,
  LEADERBOARD,
  GAME_RULES,
  SPIN_WHEEL,
}

export enum Difficulty {
  EASY = 'Easy',
  MEDIUM = 'Medium',
  HARD = 'Hard',
}

export enum Rank {
    IRON = 'Iron',
    COPPER = 'Copper',
    SILVER = 'Silver',
    GOLD = 'Gold',
    PLATINUM = 'Platinum',
    DIAMOND = 'Diamond',
    MASTER = 'Master',
    HEROIC = 'Heroic',
    GRAND_MASTER = 'Grand Master',
    PRO = 'Pro Level +++',
}


export interface HighScoreEntry {
  score: number;
  date: string;
}

export interface HighScores {
  // The key is a LevelType string, and the value is an object
  // where keys are Difficulty strings and values are the scores.
  // Values can be a number (legacy) or a HighScoreEntry object.
  [key: string]: Partial<Record<Difficulty, number | HighScoreEntry>>;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  conditionDescription: string;
}

export interface UserProfile {
  totalPointsEarned: number;
  totalRupees: number;
  highScores: HighScores;
  lastDailyChallengeDate?: string;
  username?: string;
  unlockedAchievements: string[]; // Array of Achievement IDs
}
