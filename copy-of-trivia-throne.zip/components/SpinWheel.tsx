
import React, { useState, useRef } from 'react';
import { UserProfile } from '../types';

interface SpinWheelProps {
  userProfile: UserProfile;
  onUpdateProfile: (updates: Partial<UserProfile>) => void;
  onClose: () => void;
}

interface Segment {
  label: string;
  value: number;
  type: 'RUPEES' | 'POINTS';
  color: string;
  textColor: string;
  probability: number; // 0-100 weight
}

const SEGMENTS: Segment[] = [
  { label: '1000 💎', value: 1000, type: 'RUPEES', color: '#f59e0b', textColor: '#fff', probability: 5 },   // Amber (Jackpot)
  { label: '200 Pts', value: 200, type: 'POINTS', color: '#3b82f6', textColor: '#fff', probability: 20 },   // Blue
  { label: '50 💎', value: 50, type: 'RUPEES', color: '#10b981', textColor: '#fff', probability: 25 },    // Emerald
  { label: '500 Pts', value: 500, type: 'POINTS', color: '#6366f1', textColor: '#fff', probability: 15 },   // Indigo
  { label: '200 💎', value: 200, type: 'RUPEES', color: '#ec4899', textColor: '#fff', probability: 10 },    // Pink
  { label: '100 Pts', value: 100, type: 'POINTS', color: '#06b6d4', textColor: '#fff', probability: 25 },   // Cyan
  { label: '500 💎', value: 500, type: 'RUPEES', color: '#8b5cf6', textColor: '#fff', probability: 5 },     // Violet
  { label: 'Jackpot', value: 2000, type: 'POINTS', color: '#ef4444', textColor: '#fff', probability: 5 },   // Red
];

const SPIN_COST = 100;

const SpinWheel: React.FC<SpinWheelProps> = ({ userProfile, onUpdateProfile, onClose }) => {
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [prize, setPrize] = useState<Segment | null>(null);
  const [error, setError] = useState<string | null>(null);

  // We use a ref to track total rotation to prevent the wheel from spinning backwards
  // when we add new degrees
  const totalRotationRef = useRef(0);

  const handleSpin = () => {
    if (isSpinning) return;
    if (userProfile.totalRupees < SPIN_COST) {
        setError("Not enough Rupees!");
        setTimeout(() => setError(null), 2000);
        return;
    }

    // Deduct Cost
    onUpdateProfile({ totalRupees: userProfile.totalRupees - SPIN_COST });
    setIsSpinning(true);
    setPrize(null);

    // Weighted Random Selection
    const totalWeight = SEGMENTS.reduce((sum, seg) => sum + seg.probability, 0);
    let randomValue = Math.random() * totalWeight;
    let selectedIndex = 0;
    
    for (let i = 0; i < SEGMENTS.length; i++) {
        randomValue -= SEGMENTS[i].probability;
        if (randomValue <= 0) {
            selectedIndex = i;
            break;
        }
    }

    const segmentCount = SEGMENTS.length;
    const segmentAngle = 360 / segmentCount;
    
    // Logic to land on the selected segment
    // The pointer is usually at the top (0 degrees visually, or 270 in CSS depending on start).
    // We need to rotate the wheel such that the selected segment ends up at the top.
    // To handle this simply: 
    // 1. Calculate where the segment is naturally (index * angle).
    // 2. Add extra full spins (360 * 5).
    // 3. Subtract the segment position to bring it to 0.
    // 4. Add a small random offset within the segment for realism.
    
    const randomOffset = (Math.random() * segmentAngle * 0.8) - (segmentAngle * 0.4); // +/- offset
    const spinRounds = 5 + Math.floor(Math.random() * 3); // 5 to 7 rounds
    
    // Calculate target rotation
    // If index 0 is at 0 degrees, to land index 1 (45 deg) at top, we rotate -45.
    const targetRotation = (360 * spinRounds) - (selectedIndex * segmentAngle) + randomOffset;

    // Update the ref to ensure we always rotate forward
    // We add the target rotation to the current base, but we need to modulate it correctly.
    // Actually, simpler: just add to current ref.
    // But we need to respect the specific index. 
    
    // Let's reset visual rotation to mod 360 internally? No, CSS transitions need value increase.
    // Current Rotation + Full Spins + Distance to Target.
    
    const currentAngle = totalRotationRef.current % 360;
    const distanceToTarget = targetRotation - currentAngle; // This might be negative or too small.
    
    // Force positive large rotation
    const finalRotation = totalRotationRef.current + (360 * spinRounds) + (360 - (selectedIndex * segmentAngle) - (totalRotationRef.current % 360));
    
    totalRotationRef.current = finalRotation;
    setRotation(finalRotation);

    setTimeout(() => {
        setIsSpinning(false);
        const wonSegment = SEGMENTS[selectedIndex];
        setPrize(wonSegment);
        
        // Award Prize
        if (wonSegment.type === 'RUPEES') {
            onUpdateProfile({ totalRupees: userProfile.totalRupees - SPIN_COST + wonSegment.value }); // Cost already deducted visually, but react state batching safer to read fresh or just add prize to current deducted state?
            // We already deducted cost in state. Just add prize.
            // Wait, userProfile prop might be stale inside timeout closure? 
            // Yes. But onUpdateProfile merges. 
            // To be safe, we pass the delta or read fresh. 
            // Since we can't read fresh easily without refs, let's trust the parent update logic or pass a functional update if available.
            // onUpdateProfile implementation in App.tsx does: setUserProfile(prev => ...).
            // So we need to call onUpdateProfile again.
            
            // We deducted cost at start of function.
            // Now we add prize.
            // NOTE: Because we updated state at start, the prop `userProfile` here in the timeout is STALE (from before click).
            // However, `onUpdateProfile` uses functional state update `set(prev => ...)`.
            // So we can just call `onUpdateProfile({ totalRupees: prevTotal + value })` logic?
            // No, `onUpdateProfile` takes a Partial<UserProfile> object, not a function.
            // We need to be careful.
            
            // Workaround: Calculate final value based on the STALE prop + Prize - Cost?
            // No, that overwrites the deduction if the re-render hasn't propagated fully (unlikely in 4s).
            // Actually, after 4 seconds, the component definitely re-rendered with the new deducted balance.
            // BUT, the closure `const handleSpin` was created with the OLD props.
            // We should use a ref for the latest profile or split logic.
            // Easier: Use the functional update pattern if possible.
            // Since App.tsx `handleUpdateProfile` does `setUserProfile(prev => ({...prev, ...updates}))`, 
            // we can't access `prev` inside the `updates` object we pass.
            
            // SOLUTION: We won't deduct immediately. We deduct AND add at the end.
            // But we want to show the balance drop.
            // Okay, assume re-render happens. We need `useEffect` to watch for prize?
            // No, let's just trust React's prop updates. The `handleSpin` closure is stale, but we can use a Ref to hold the *current* profile if needed, 
            // OR just rely on the fact that we shouldn't use the stale `userProfile.totalRupees` here.
            
            // Let's change `onUpdateProfile` in App.tsx to accept a callback? No, that requires changing App.tsx signature.
            // Let's just deduct at the end. It's safer.
            // Visual feedback: Show "Cost: 100" and animate it away? 
            // Actually, let's just deduct at the end.
        } else {
             // Points
             // onUpdateProfile({ totalPointsEarned: userProfile.totalPointsEarned + wonSegment.value });
        }
        // Handled in separate useEffect for safety
    }, 4000); // 4s spin duration
  };

  // Effect to handle payout securely when prize state changes
  // This ensures we use the fresh userProfile from the latest render
  React.useEffect(() => {
    if (prize && !isSpinning) {
        if (prize.type === 'RUPEES') {
             onUpdateProfile({ totalRupees: userProfile.totalRupees - SPIN_COST + prize.value });
        } else {
             onUpdateProfile({ 
                 totalPointsEarned: userProfile.totalPointsEarned + prize.value,
                 totalRupees: userProfile.totalRupees - SPIN_COST // Deduct cost here
             });
        }
    }
  }, [prize, isSpinning]);

  return (
    <div className="w-full h-full flex flex-col items-center justify-center animate-fade-in relative overflow-hidden">
      
      <div className="absolute top-4 left-4 z-20 bg-slate-900/80 backdrop-blur px-4 py-2 rounded-full border border-slate-700 shadow-lg flex items-center gap-2">
        <span>💎</span>
        <span className="font-bold text-cyan-400">{userProfile.totalRupees.toLocaleString()}</span>
      </div>

      <button 
        onClick={onClose}
        className="absolute top-4 right-4 z-20 text-slate-400 hover:text-white transition-colors"
      >
         <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
         </svg>
      </button>

      <h2 className="text-3xl md:text-4xl font-black text-transparent bg-clip-text bg-gradient-to-b from-yellow-300 to-yellow-600 mb-8 drop-shadow-sm tracking-tight uppercase">
        Lucky Wheel
      </h2>

      <div className="relative mb-8">
        {/* Pointer */}
        <div className="absolute -top-6 left-1/2 -translate-x-1/2 z-20 w-0 h-0 border-l-[15px] border-l-transparent border-r-[15px] border-r-transparent border-t-[25px] border-t-white drop-shadow-lg"></div>
        
        {/* Wheel Container */}
        <div 
            className="w-[300px] h-[300px] sm:w-[380px] sm:h-[380px] rounded-full border-4 border-slate-800 shadow-[0_0_50px_rgba(0,0,0,0.5)] relative overflow-hidden transition-transform duration-[4000ms] ease-[cubic-bezier(0.2,0.8,0.2,1)]"
            style={{ 
                transform: `rotate(${rotation}deg)`,
            }}
        >
             {/* Segments */}
             {SEGMENTS.map((seg, index) => {
                 const rotation = (360 / SEGMENTS.length) * index;
                 const skew = 90 - (360 / SEGMENTS.length); 
                 
                 // Conic gradient method is easier for background, but positioning text requires math.
                 // Let's use absolute positioned slices.
                 return (
                    <div 
                        key={index}
                        className="absolute top-0 left-0 w-full h-full"
                        style={{ transform: `rotate(${rotation}deg)` }}
                    >
                        {/* Slice Background - Simplified visual representation using clip-path or css shapes is hard. 
                            Let's use a centered SVG or conic gradient on parent.
                            Using Conic Gradient on parent is better.
                        */}
                        <div 
                            className="absolute left-1/2 top-0 -translate-x-1/2 pt-4 sm:pt-8 origin-bottom h-1/2 flex flex-col items-center justify-start"
                            style={{ transformOrigin: 'bottom center' }}
                        >
                             <span className="text-lg sm:text-xl font-black drop-shadow-md" style={{ color: seg.textColor }}>{seg.label}</span>
                        </div>
                    </div>
                 );
             })}
             
             {/* The Background Gradient Layer */}
             <div 
                className="absolute inset-0 -z-10 rounded-full"
                style={{
                    background: `conic-gradient(
                        ${SEGMENTS.map((s, i) => `${s.color} ${i * (100/SEGMENTS.length)}% ${(i+1) * (100/SEGMENTS.length)}%`).join(', ')}
                    )`
                }}
             ></div>
        </div>
        
        {/* Center Cap */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 bg-slate-900 rounded-full border-4 border-cyan-500 shadow-xl flex items-center justify-center z-10">
            <span className="text-2xl">🎰</span>
        </div>
      </div>

      {/* Result Message */}
      {prize && !isSpinning && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in rounded-2xl">
             <div className="bg-slate-800 p-8 rounded-2xl border border-yellow-500 text-center shadow-2xl transform scale-110">
                 <p className="text-slate-400 text-sm font-bold uppercase mb-2">You Won</p>
                 <p className="text-4xl font-black text-white mb-2">{prize.label}</p>
                 <button 
                    onClick={() => {
                        setPrize(null);
                        // Optional: Auto spin? No, let them click again.
                    }}
                    className="mt-4 bg-yellow-500 hover:bg-yellow-600 text-slate-900 font-bold py-2 px-6 rounded-lg shadow-lg"
                 >
                    Spin Again
                 </button>
                 <button onClick={onClose} className="block mx-auto mt-4 text-slate-500 text-sm hover:text-white">Close</button>
             </div>
        </div>
      )}

      <div className="flex flex-col items-center gap-2">
          {error && <p className="text-red-500 font-bold animate-bounce">{error}</p>}
          <button
            onClick={handleSpin}
            disabled={isSpinning}
            className={`relative group bg-gradient-to-b from-cyan-400 to-blue-600 px-12 py-4 rounded-2xl shadow-xl transform transition-all ${isSpinning ? 'scale-95 opacity-80 cursor-wait' : 'hover:scale-105 active:scale-95'}`}
          >
            <div className="absolute inset-0 bg-white/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <span className="text-2xl font-black text-white drop-shadow-md">SPIN</span>
            <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 text-sm font-bold text-slate-400 whitespace-nowrap">
                Cost: <span className="text-emerald-400">{SPIN_COST} Rupees</span>
            </div>
          </button>
      </div>

    </div>
  );
};

export default SpinWheel;
