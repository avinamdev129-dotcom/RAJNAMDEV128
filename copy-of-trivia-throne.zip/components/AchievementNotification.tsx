
import React, { useEffect, useState } from 'react';
import { Achievement } from '../types';

interface AchievementNotificationProps {
  achievement: Achievement;
  onClose: () => void;
}

const AchievementNotification: React.FC<AchievementNotificationProps> = ({ achievement, onClose }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Trigger enter animation
    const timer = setTimeout(() => setIsVisible(true), 50);
    
    // Auto dismiss
    const closeTimer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(onClose, 500); // Wait for exit animation
    }, 4000);

    return () => {
      clearTimeout(timer);
      clearTimeout(closeTimer);
    };
  }, [onClose]);

  return (
    <div className={`fixed top-20 left-1/2 transform -translate-x-1/2 z-[100] transition-all duration-500 ease-out ${isVisible ? 'translate-y-0 opacity-100' : '-translate-y-10 opacity-0'}`}>
      <div className="bg-slate-800/90 backdrop-blur-md border border-yellow-500/50 text-white px-6 py-4 rounded-2xl shadow-[0_0_30px_rgba(234,179,8,0.3)] flex items-center gap-4 max-w-sm w-full">
        <div className="relative">
            <div className="absolute inset-0 bg-yellow-400 blur-lg opacity-50 animate-pulse rounded-full"></div>
            <div className="relative text-4xl filter drop-shadow-lg animate-bounce">
                {achievement.icon}
            </div>
        </div>
        <div>
            <p className="text-yellow-400 text-xs font-bold uppercase tracking-widest mb-0.5">Achievement Unlocked</p>
            <p className="font-bold text-lg leading-tight">{achievement.title}</p>
            <p className="text-slate-300 text-xs mt-1">{achievement.description}</p>
        </div>
      </div>
    </div>
  );
};

export default AchievementNotification;
