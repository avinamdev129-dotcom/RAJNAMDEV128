
import React, { useState } from 'react';

interface OnboardingProps {
  onSetUsername: (name: string) => void;
}

const PROHIBITED_WORDS = [
    'abuse', 'abusive', 'admin', 'administrator', 'mod', 'moderator', 
    'stupid', 'idiot', 'fool', 'hate', 'kill', 'murder', 'death', 
    'racist', 'sex', 'sexy', 'nude', 'naked', 'damn', 'hell', 'suck'
];

const Onboarding: React.FC<OnboardingProps> = ({ onSetUsername }) => {
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [showMobileInstructions, setShowMobileInstructions] = useState(false);
  const [gameUrl, setGameUrl] = useState('');
  const [isLocalhost, setIsLocalhost] = useState(false);

  React.useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const url = new URL(window.location.href);
        url.hash = '';
        setGameUrl(url.toString());
        
        if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1' || window.location.protocol === 'file:') {
          setIsLocalhost(true);
        }
      } catch (e) {
        setGameUrl(window.location.href.split('#')[0]);
      }
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = name.trim();

    if (trimmedName.length < 2) {
      setError('Please enter a valid name (at least 2 characters).');
      return;
    }

    const lowerName = trimmedName.toLowerCase();
    const containsBadWord = PROHIBITED_WORDS.some(word => lowerName.includes(word));

    if (containsBadWord) {
        setError('Please choose a respectful username.');
        setName('');
        return;
    }

    onSetUsername(trimmedName);
  };

  return (
    <div className="flex flex-col items-center justify-center h-full w-full animate-fade-in px-4 py-6 relative">
      
      {/* Hero Icon */}
      <div className="relative mb-8 group perspective-500">
        <div className="absolute -inset-4 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-full blur-xl opacity-40 group-hover:opacity-60 transition duration-1000 group-hover:duration-200 animate-pulse"></div>
        <div className="relative w-28 h-28 sm:w-32 sm:h-32 bg-slate-900/90 backdrop-blur-xl rounded-full flex items-center justify-center border border-cyan-500/30 shadow-2xl transform transition-transform duration-500 hover:scale-110 hover:rotate-3">
           <span className="text-6xl sm:text-7xl filter drop-shadow-lg animate-[bounce_3s_infinite]">👑</span>
        </div>
      </div>

      {/* Text Content */}
      <div className="text-center mb-10 space-y-3">
        <h1 className="text-4xl sm:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-blue-400 to-indigo-400 tracking-tight drop-shadow-sm">
          Trivia Throne
        </h1>
        <p className="text-slate-400 text-sm sm:text-base max-w-xs mx-auto leading-relaxed font-medium">
          Enter the realm of knowledge.<br/>Claim your crown.
        </p>
      </div>

      {/* Interactive Form */}
      <form onSubmit={handleSubmit} className="w-full max-w-xs sm:max-w-sm space-y-6 relative z-10">
        <div className="space-y-2">
            <label htmlFor="username" className="text-xs font-bold text-cyan-400 uppercase tracking-widest ml-1">
                Enter Your Name
            </label>
            <div className="relative group">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-cyan-500 to-indigo-500 rounded-xl blur opacity-20 group-hover:opacity-50 transition duration-500"></div>
                <input
                    id="username"
                    type="text"
                    value={name}
                    onChange={(e) => {
                        setName(e.target.value);
                        if (error) setError('');
                    }}
                    placeholder="Hero Name..."
                    className="relative w-full bg-slate-900 border border-slate-700 text-white text-center text-lg font-bold rounded-xl py-4 px-4 focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 transition-all placeholder-slate-600 shadow-inner"
                    autoFocus
                    maxLength={15}
                    autoComplete="off"
                />
            </div>
        </div>
        
        {error && (
            <div className="text-red-400 text-xs sm:text-sm text-center bg-red-500/10 py-2 px-3 rounded-lg border border-red-500/20 animate-pulse font-semibold">
                ⚠️ {error}
            </div>
        )}

        <button
          type="submit"
          className="w-full group relative py-4 px-6 rounded-xl overflow-hidden bg-slate-800 text-white shadow-[0_0_20px_rgba(0,0,0,0.3)] transition-all hover:-translate-y-1 active:translate-y-0.5 active:scale-[0.98]"
        >
          <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-600 opacity-90 group-hover:opacity-100 transition-opacity duration-300"></div>
          <div className="relative flex items-center justify-center gap-3 font-black text-lg tracking-wide uppercase text-white">
             <span>Begin Quest</span>
             <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
             </svg>
          </div>
        </button>
      </form>

      <button 
        onClick={() => setShowMobileInstructions(true)}
        className="mt-8 bg-slate-800 hover:bg-slate-700 text-cyan-400 font-bold py-3 px-6 rounded-full transition-all text-xs uppercase tracking-widest border border-slate-700 shadow-lg flex items-center gap-2"
      >
        <span>📲</span> Install App
      </button>
      
      {/* Mobile Instructions Modal */}
      {showMobileInstructions && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-slate-900/95 backdrop-blur-md rounded-2xl p-4 animate-fade-in overflow-y-auto">
            <div className="bg-slate-800 border border-slate-700 p-5 rounded-2xl shadow-2xl w-full max-w-sm relative text-center my-auto">
                <button onClick={() => setShowMobileInstructions(false)} className="absolute top-2 right-2 text-slate-400 hover:text-white p-2">
                    ✕
                </button>
                <div className="text-4xl mb-2">📲</div>
                <h3 className="text-xl font-bold text-white mb-4">Install App</h3>
                
                {isLocalhost ? (
                  <div className="bg-red-500/10 border border-red-500/30 p-3 rounded-xl text-left">
                       <p className="text-red-400 font-bold text-sm mb-1">⚠️ Running on Computer</p>
                       <p className="text-slate-300 text-xs">
                         This is a local preview. You must <b>Deploy</b> the game or <b>Build an APK</b> to install it on a phone.
                       </p>
                  </div>
                ) : (
                    <div className="text-left space-y-4">
                        <div className="bg-slate-900/50 p-3 rounded-lg border border-slate-700">
                             <p className="text-white text-sm font-bold">Android Users:</p>
                             <p className="text-slate-400 text-xs">Tap <span className="text-white font-bold">Menu ⋮</span> {'>'} <span className="text-white font-bold">Install App</span></p>
                        </div>
                        <div className="bg-slate-900/50 p-3 rounded-lg border border-slate-700">
                             <p className="text-white text-sm font-bold">iPhone Users:</p>
                             <p className="text-slate-400 text-xs">Tap <span className="text-white font-bold">Share</span> {'>'} <span className="text-white font-bold">Add to Home Screen</span></p>
                        </div>
                    </div>
                )}
            </div>
        </div>
      )}
    </div>
  );
};

export default Onboarding;
