
import React from 'react';

interface FlagDisplayProps {
  flagEmoji: string;
}

const FlagDisplay: React.FC<FlagDisplayProps> = ({ flagEmoji }) => {
  return (
    <div className="flex justify-center items-center my-4 md:my-8">
      <div className="text-7xl md:text-9xl lg:text-[12rem] p-4 bg-slate-700/50 rounded-2xl shadow-inner">
        {flagEmoji}
      </div>
    </div>
  );
};

export default FlagDisplay;
