
import React from 'react';

interface QuestionDisplayProps {
  question: string;
}

const QuestionDisplay: React.FC<QuestionDisplayProps> = ({ question }) => {
  return (
    <div className="flex justify-center items-center my-4 min-h-[150px] lg:min-h-[200px] w-full">
      <div className="relative group w-full">
        <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-2xl blur opacity-20 group-hover:opacity-30 transition duration-500"></div>
        <div className="relative bg-slate-800/80 backdrop-blur-md border border-slate-700 p-6 md:p-8 lg:p-10 rounded-2xl shadow-2xl flex items-center justify-center h-full w-full">
             <p className="text-xl md:text-2xl lg:text-3xl text-center font-bold text-white leading-relaxed tracking-wide drop-shadow-sm">
                {question}
            </p>
        </div>
      </div>
    </div>
  );
};

export default QuestionDisplay;
