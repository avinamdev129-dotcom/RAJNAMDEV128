
import React, { useState, useEffect, useRef } from 'react';
import { Difficulty, LevelType } from '../types';

interface GameResultProps {
  score: number;
  totalRounds: number;
  onRestart: () => void;
  maxPointsPerRound: number;
  rupeesEarned: number;
  levelType: LevelType;
  difficulty: Difficulty;
  dailyChallengeBonus?: number;
  isNewHighScore?: boolean;
}

const GameResult: React.FC<GameResultProps> = ({ score, totalRounds, onRestart, maxPointsPerRound, rupeesEarned, levelType, difficulty, dailyChallengeBonus = 0, isNewHighScore = false }) => {
  const [copied, setCopied] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const maxScore = totalRounds * maxPointsPerRound;
  const percentage = maxScore > 0 ? Math.round((score / maxScore) * 100) : 0;

  // Confetti Effect
  useEffect(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles: { x: number; y: number; size: number; speedX: number; speedY: number; color: string }[] = [];
    const colors = ['#06b6d4', '#3b82f6', '#f59e0b', '#ef4444', '#10b981'];
    
    // More particles for high score
    const particleCount = isNewHighScore ? 200 : 100;

    for (let i = 0; i < particleCount; i++) {
        particles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height - canvas.height,
            size: Math.random() * 5 + 2,
            speedX: Math.random() * 2 - 1,
            speedY: Math.random() * 3 + 2,
            color: colors[Math.floor(Math.random() * colors.length)]
        });
    }

    let animationId: number;
    const animate = () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        particles.forEach((p) => {
            p.y += p.speedY;
            p.x += p.speedX;
            if (p.y > canvas.height) p.y = -10;
            ctx.fillStyle = p.color;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
        });
        animationId = requestAnimationFrame(animate);
    };

    animate();
    
    // Stop after 6 seconds for high score, 4 for normal
    const timer = setTimeout(() => cancelAnimationFrame(animationId), isNewHighScore ? 6000 : 4000);

    return () => {
        cancelAnimationFrame(animationId);
        clearTimeout(timer);
    };
  }, [isNewHighScore]);


  let feedback = {
    title: "",
    message: ""
  };
  
  if (levelType === LevelType.DAILY_CHALLENGE) {
    feedback = { title: "Challenge Complete!", message: "You conquered the daily challenge! Come back tomorrow for a new one." };
  } else if (percentage >= 95) {
    feedback = { title: "Perfect Score!", message: "You're a true genius!" };
  } else if (percentage >= 80) {
    feedback = { title: "Excellent!", message: "You really know your stuff!" };
  } else if (percentage >= 50) {
    feedback = { title: "Good Job!", message: "A very respectable score." };
  } else {
    feedback = { title: "Nice Try!", message: "Keep practicing to improve!" };
  }

  const handleShareOrCopy = async () => {
    // Generate Robust Clean URL including Params
    let url = window.location.href;
    try {
        const urlObj = new URL(window.location.href);
        urlObj.hash = ''; // Just remove the hash
        url = urlObj.toString();
    } catch (e) {
        url = window.location.href.split('#')[0];
    }

    const shareText = dailyChallengeBonus > 0
      ? `I just beat the Daily Challenge, scoring ${score} points and earning +${rupeesEarned} Rupees! 🏆 Can you beat my score tomorrow?`
      : `I just scored ${score} points (${percentage}%) on the ${difficulty} ${levelType} quiz and earned +${rupeesEarned} Rupees! 🏆 Can you beat my score?`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Trivia Throne Challenge!',
          text: shareText,
          url: url,
        });
      } catch (error) {
        console.error('Error sharing score:', error);
      }
    } else if (navigator.clipboard) {
      try {
        await navigator.clipboard.writeText(`${shareText} Play here: ${url}`);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000); // Reset after 2 seconds
      } catch (error) {
        console.error('Error copying to clipboard:', error);
        alert("Failed to copy results to clipboard.");
      }
    }
  };

  const canShareOrCopy = navigator.share || navigator.clipboard;

  return (
    <div className="text-center flex flex-col items-center justify-center h-full animate-fade-in relative py-4">
      <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none z-0 opacity-50" />
      <div className="relative z-10 w-full flex flex-col items-center">
        
        {/* High Score Banner */}
        {isNewHighScore && (
            <div className="animate-bounce mb-4 bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 text-white px-6 py-2 rounded-full font-black uppercase tracking-widest shadow-lg border-2 border-yellow-200 transform rotate-1">
                🏆 New High Score! 🏆
            </div>
        )}

        <h2 className="text-3xl font-bold text-cyan-400 mb-2 drop-shadow-md">{feedback.title}</h2>
        <p className="text-slate-300 text-lg mb-6">{feedback.message}</p>
        
        <div className="bg-slate-800/60 p-6 rounded-2xl mb-8 w-full max-w-sm backdrop-blur-md border border-slate-700/50 shadow-xl">
            <div className="mb-4">
            <p className="text-xl text-slate-300 uppercase font-bold tracking-wide">Score</p>
            <p className="text-6xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white to-slate-400 my-2 drop-shadow-sm">{score}</p>
            <div className="w-full bg-slate-700 rounded-full h-2.5 mt-2 overflow-hidden">
                <div className="bg-cyan-500 h-2.5 rounded-full" style={{ width: `${percentage}%` }}></div>
            </div>
            <p className="text-sm text-cyan-400 font-bold mt-1 text-right">{percentage}%</p>
            </div>
            
            <div className="border-t border-slate-700/50 pt-4 mt-4">
            <p className="text-lg text-slate-300 font-bold">Earnings</p>
            <div className="flex items-center justify-center gap-2 my-2">
                 <span className="text-3xl animate-pulse">💎</span>
                 <p className="text-4xl font-bold text-emerald-400">+{rupeesEarned}</p>
            </div>
            
            {dailyChallengeBonus > 0 && (
                <p className="text-sm font-bold text-yellow-400 animate-pulse mt-1 bg-yellow-400/10 py-1 rounded-lg">
                    +{dailyChallengeBonus} Bonus!
                </p>
            )}
            </div>
        </div>

        <div className="w-full max-w-sm flex flex-col sm:flex-row items-center gap-4">
            <button onClick={onRestart} className="w-full bg-cyan-500 hover:bg-cyan-400 text-slate-900 font-bold py-3 px-6 rounded-xl transition-all text-lg shadow-lg hover:shadow-cyan-500/30 flex-grow hover:-translate-y-1 active:translate-y-0">
            Play Again
            </button>
            {canShareOrCopy && (
            <button 
                onClick={handleShareOrCopy} 
                className="w-full sm:w-auto bg-slate-700 hover:bg-slate-600 text-white font-bold py-3 px-6 rounded-xl transition-all text-lg shadow-lg flex items-center justify-center gap-2 hover:-translate-y-1 active:translate-y-0"
                aria-label={navigator.share ? "Share your score" : "Copy your score"}
            >
                {navigator.share ? (
                <>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M15 8a3 3 0 10-2.977-2.63l-4.94 2.47a3 3 0 100 4.319l4.94 2.47a3 3 0 10.895-1.789l-4.94-2.47a3.027 3.027 0 000-.74l4.94-2.47C13.456 7.68 14.19 8 15 8z" />
                    </svg>
                    <span>Share</span>
                </>
                ) : (
                copied ? (
                    <>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-400" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-green-400">Copied!</span>
                    </>
                ) : (
                    <>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M8 3a1 1 0 011-1h2a1 1 0 110 2H9a1 1 0 01-1-1z" />
                        <path d="M6 3a2 2 0 00-2 2v11a2 2 0 002 2h8a2 2 0 002-2V5a2 2 0 00-2-2 3 3 0 01-3 3H9a3 3 0 01-3-3z" />
                    </svg>
                    <span>Copy</span>
                    </>
                )
                )}
            </button>
            )}
        </div>
      </div>
    </div>
  );
};

export default GameResult;
