
import React, { useState } from 'react';
import { UserProfile, LevelType, Difficulty, Rank } from '../types';
import { ACHIEVEMENTS } from '../App';

interface ProfileDisplayProps {
  userProfile: UserProfile;
  onClose: () => void;
  onUpdateProfile: (updates: Partial<UserProfile>) => void;
  onResetProfile: () => void;
}

const getRankInfo = (points: number): { name: Rank; color: string; icon: string } => {
    if (points >= 500000) return { name: Rank.PRO, color: 'from-fuchsia-600 to-purple-600', icon: '👑' };
    if (points >= 150000) return { name: Rank.GRAND_MASTER, color: 'from-red-600 to-orange-600', icon: '⚔️' };
    if (points >= 80000) return { name: Rank.HEROIC, color: 'from-orange-500 to-amber-500', icon: '🦁' };
    if (points >= 40000) return { name: Rank.MASTER, color: 'from-violet-600 to-indigo-600', icon: '🔮' };
    if (points >= 20000) return { name: Rank.DIAMOND, color: 'from-cyan-500 to-blue-600', icon: '💎' };
    if (points >= 10000) return { name: Rank.PLATINUM, color: 'from-teal-400 to-emerald-600', icon: '💠' };
    if (points >= 4000) return { name: Rank.GOLD, color: 'from-yellow-400 to-amber-500', icon: '🥇' };
    if (points >= 1500) return { name: Rank.SILVER, color: 'from-slate-400 to-gray-500', icon: '🥈' };
    if (points >= 500) return { name: Rank.COPPER, color: 'from-orange-700 to-yellow-700', icon: '🥉' };
    return { name: Rank.IRON, color: 'from-stone-600 to-stone-800', icon: '🛡️' };
};

const ProfileDisplay: React.FC<ProfileDisplayProps> = ({ userProfile, onClose, onUpdateProfile, onResetProfile }) => {
  const levelOrder = [LevelType.FLAGS, LevelType.SCIENCE, LevelType.HISTORY, LevelType.WORLD_GEOGRAPHY, LevelType.DAILY_CHALLENGE];
  const difficultyOrder = [Difficulty.EASY, Difficulty.MEDIUM, Difficulty.HARD];

  const hasScores = Object.keys(userProfile.highScores).length > 0;
  const rankInfo = getRankInfo(userProfile.totalPointsEarned);
  const hasCrown = userProfile.totalPointsEarned >= 40000; // Master Rank+
  
  const [isRankAnimating, setIsRankAnimating] = useState(false);
  const [isRupeeAnimating, setIsRupeeAnimating] = useState(false);
  const [activeTab, setActiveTab] = useState<'stats' | 'achievements'>('stats');
  
  // Reset Confirmation
  const [isResetConfirming, setIsResetConfirming] = useState(false);

  // Name Edit State
  const [isEditingName, setIsEditingName] = useState(false);
  const [newUsername, setNewUsername] = useState(userProfile.username || '');


  const handleRankClick = () => {
    if (!isRankAnimating) {
      setIsRankAnimating(true);
      setTimeout(() => setIsRankAnimating(false), 700); 
    }
  };

  const handleRupeeClick = () => {
    if (!isRupeeAnimating) {
      setIsRupeeAnimating(true);
      setTimeout(() => setIsRupeeAnimating(false), 500); 
    }
  };

  const handleSaveName = () => {
    if (newUsername.trim().length < 2) {
      return; // Simple validation
    }
    onUpdateProfile({ username: newUsername.trim() });
    setIsEditingName(false);
  };

  return (
    <div className="w-full h-full flex flex-col animate-fade-in px-2 sm:px-4 pb-2 relative">
      
      {/* User Name and Edit */}
      <div className="flex items-center justify-between mb-4">
          {isEditingName ? (
            <div className="flex items-center gap-2 w-full">
              <input 
                type="text" 
                value={newUsername}
                onChange={(e) => setNewUsername(e.target.value)}
                className="bg-slate-800 border border-slate-600 rounded px-2 py-1 text-white flex-grow focus:border-cyan-400 outline-none"
                autoFocus
              />
              <button onClick={handleSaveName} className="text-green-400 hover:text-green-300">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <div className="relative">
                 <h2 className="text-xl font-bold text-cyan-400">
                    {userProfile.username ? userProfile.username : 'Adventurer'}
                 </h2>
                 {hasCrown && (
                    <span className="absolute -top-3 -right-5 text-2xl animate-bounce filter drop-shadow-[0_0_5px_rgba(234,179,8,0.8)]">
                        👑
                    </span>
                 )}
              </div>
              <button onClick={() => setIsEditingName(true)} className="text-slate-500 hover:text-cyan-400 transition-colors ml-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                </svg>
              </button>
            </div>
          )}
      </div>

      {/* Header Area - Rank */}
      <div className="flex-shrink-0 mb-6 relative group perspective-1000">
        {/* Glow effect behind the card */}
        <div className={`absolute inset-0 bg-gradient-to-r ${rankInfo.color} blur-2xl opacity-40 group-hover:opacity-60 transition-opacity duration-500 rounded-2xl -z-10`}></div>
        
        <div 
            onClick={handleRankClick}
            className={`p-6 sm:p-8 rounded-2xl bg-gradient-to-br ${rankInfo.color} shadow-[0_10px_40px_-10px_rgba(0,0,0,0.5)] relative overflow-hidden border border-white/20 cursor-pointer transition-all duration-300 transform ${isRankAnimating ? 'scale-95 ring-4 ring-white/30' : 'hover:-translate-y-1 hover:scale-[1.01]'}`}
        >
            {/* Animated Sheen/Reflection */}
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none"></div>

            {/* Decorative Background Blobs */}
            <div className="absolute top-0 right-0 -mt-6 -mr-6 w-40 h-40 bg-white opacity-10 rounded-full blur-3xl group-hover:scale-125 transition-transform duration-700"></div>
            <div className="absolute bottom-0 left-0 -mb-6 -ml-6 w-32 h-32 bg-black opacity-20 rounded-full blur-2xl"></div>

            <div className="flex items-center justify-between relative z-10">
                <div className="flex flex-col justify-center">
                    <div className="flex items-center gap-2 mb-2">
                        <span className="bg-black/30 text-white/90 text-[10px] sm:text-xs font-bold px-3 py-1 rounded-full uppercase tracking-widest backdrop-blur-sm border border-white/10 shadow-sm">
                            Current Rank
                        </span>
                        {userProfile.totalPointsEarned > 10000 && (
                           <span className="animate-pulse text-yellow-300 filter drop-shadow-md">✨</span>
                        )}
                    </div>
                    <h2 className="text-3xl sm:text-5xl font-black text-white drop-shadow-lg tracking-wide mb-1">
                        {rankInfo.name}
                    </h2>
                    <div className="h-1.5 w-full bg-black/20 rounded-full mt-2 overflow-hidden max-w-[120px] border border-white/10">
                        <div className="h-full bg-white/60 rounded-full w-full animate-[pulse_3s_infinite]"></div>
                    </div>
                </div>
                
                {/* Icon Container */}
                <div className="relative">
                    {/* Glow behind icon */}
                    <div className={`absolute inset-0 bg-white/40 blur-[40px] rounded-full transform scale-110 ${isRankAnimating ? 'animate-pulse' : ''}`}></div>
                    
                    <div className={`text-6xl sm:text-8xl filter drop-shadow-2xl transition-all duration-700 ease-out transform ${isRankAnimating ? 'rotate-[360deg] scale-125' : 'group-hover:rotate-6 group-hover:scale-110'}`}>
                        {rankInfo.icon}
                    </div>
                    {hasCrown && (
                        <div className="absolute -top-4 -right-4 text-5xl animate-bounce filter drop-shadow-lg z-20">👑</div>
                    )}
                </div>
            </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-3 sm:gap-4 mb-4 flex-shrink-0">
        <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/50 flex flex-col items-center justify-center hover:bg-slate-700/60 transition-colors shadow-lg">
            <p className="text-slate-400 text-xs sm:text-sm uppercase font-bold tracking-wide mb-1">Total Score</p>
            <p className="text-xl sm:text-3xl font-bold text-cyan-400">{userProfile.totalPointsEarned.toLocaleString()}</p>
        </div>
        <div 
            onClick={handleRupeeClick}
            className={`bg-slate-800/60 p-4 rounded-xl border border-slate-700/50 flex flex-col items-center justify-center transition-all duration-300 shadow-lg cursor-pointer select-none ${isRupeeAnimating ? 'animate-pulse bg-yellow-900/20 border-yellow-500/50 shadow-yellow-500/10' : 'hover:bg-slate-700/60'}`}
        >
            <p className={`text-slate-400 text-xs sm:text-sm uppercase font-bold tracking-wide mb-1 transition-colors ${isRupeeAnimating ? 'text-yellow-200' : ''}`}>Total Rupees</p>
            <p className="text-xl sm:text-3xl font-bold text-emerald-400 flex items-center gap-2">
               <span className={`text-lg sm:text-2xl transition-transform duration-700 ${isRupeeAnimating ? 'rotate-[360deg]' : ''}`}>💎</span> 
               <span className={`transition-all duration-300 ${isRupeeAnimating ? 'text-yellow-400' : ''}`}>{userProfile.totalRupees.toLocaleString()}</span>
            </p>
        </div>
      </div>

      {/* Tabs for Stats/Achievements */}
      <div className="flex mb-2 bg-slate-800/50 p-1 rounded-lg border border-slate-700/50">
        <button 
            onClick={() => setActiveTab('stats')}
            className={`flex-1 py-2 text-sm font-bold rounded-md transition-all ${activeTab === 'stats' ? 'bg-slate-700 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
        >
            High Scores
        </button>
        <button 
             onClick={() => setActiveTab('achievements')}
             className={`flex-1 py-2 text-sm font-bold rounded-md transition-all ${activeTab === 'achievements' ? 'bg-slate-700 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
        >
            Achievements
        </button>
      </div>

      {/* Scrollable Content Area */}
      <div className="flex-grow overflow-hidden flex flex-col min-h-0 bg-slate-900/30 rounded-xl border border-slate-800 shadow-inner">
        <div className="overflow-y-auto p-3 custom-scrollbar h-full">
            
            {activeTab === 'stats' && (
                <div className="space-y-3">
                    {hasScores ? (
                        levelOrder.map(level => userProfile.highScores[level] && (
                            <div key={level} className="bg-slate-800/80 rounded-lg p-3 border border-slate-700/50 hover:border-slate-600 transition-colors">
                                <div className="flex items-center justify-between mb-3 border-b border-slate-700/50 pb-2">
                                    <span className="font-bold text-slate-200 text-sm sm:text-base">{level}</span>
                                </div>
                                <div className="grid grid-cols-3 gap-2 text-center">
                                    {difficultyOrder.map(diff => {
                                        const entry = userProfile.highScores[level]?.[diff];
                                        const score = (entry && typeof entry === 'object') ? entry.score : entry;
                                        const date = (entry && typeof entry === 'object') ? entry.date : null;
                                        
                                        let diffClass = "text-slate-500";
                                        if (diff === Difficulty.EASY) diffClass = "text-green-400";
                                        if (diff === Difficulty.MEDIUM) diffClass = "text-yellow-400";
                                        if (diff === Difficulty.HARD) diffClass = "text-red-400";
                                        
                                        return (
                                            <div 
                                                key={diff} 
                                                className="bg-slate-900/50 rounded p-2 flex flex-col items-center relative group/tooltip hover:bg-slate-800 transition-colors cursor-default"
                                            >
                                                {date && (
                                                    <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 hidden group-hover/tooltip:block z-50 pointer-events-none w-max max-w-[200px]">
                                                        <div className="bg-slate-900 text-[10px] text-cyan-100 px-2 py-1.5 rounded border border-cyan-500/30 shadow-2xl text-center backdrop-blur-md">
                                                            <span className="block text-slate-400 text-[9px] uppercase tracking-wider">Achieved on</span>
                                                            {date}
                                                        </div>
                                                        <div className="w-2 h-2 bg-slate-900 border-r border-b border-cyan-500/30 transform rotate-45 absolute left-1/2 -translate-x-1/2 -bottom-1"></div>
                                                    </div>
                                                )}
                                                <span className={`text-[10px] uppercase font-bold mb-1 opacity-80 ${diffClass}`}>{diff}</span>
                                                <span className={`font-mono font-bold text-base sm:text-lg ${score !== undefined ? 'text-white' : 'text-slate-700'}`}>
                                                    {score !== undefined ? score.toLocaleString() : '--'}
                                                </span>
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="flex flex-col items-center justify-center h-40 text-slate-500">
                            <p>No high scores recorded yet.</p>
                            <p className="text-sm mt-2 text-slate-600">Complete a game to see your stats here!</p>
                        </div>
                    )}
                </div>
            )}

            {activeTab === 'achievements' && (
                <div className="grid grid-cols-2 gap-3">
                    {ACHIEVEMENTS.map(achievement => {
                        const isUnlocked = userProfile.unlockedAchievements?.includes(achievement.id);
                        
                        return (
                            <div 
                                key={achievement.id} 
                                className={`relative p-3 rounded-xl border transition-all group ${isUnlocked ? 'bg-slate-800/90 border-yellow-500/30 shadow-[0_0_15px_rgba(234,179,8,0.1)]' : 'bg-slate-900/50 border-slate-800 opacity-70'}`}
                            >
                                <div className="flex items-start gap-3">
                                    <div className={`text-3xl p-2 rounded-lg ${isUnlocked ? 'bg-yellow-500/20' : 'bg-slate-800 grayscale contrast-50'}`}>
                                        {achievement.icon}
                                    </div>
                                    <div>
                                        <p className={`text-sm font-bold leading-tight mb-1 ${isUnlocked ? 'text-yellow-100' : 'text-slate-500'}`}>
                                            {achievement.title}
                                        </p>
                                        <p className="text-[10px] text-slate-400 leading-snug">
                                            {isUnlocked ? achievement.description : achievement.conditionDescription}
                                        </p>
                                    </div>
                                </div>
                                {isUnlocked && (
                                     <div className="absolute top-2 right-2 w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
                                )}
                            </div>
                        );
                    })}
                </div>
            )}

        </div>
      </div>

      {/* Footer Actions */}
      <div className="mt-4 flex-shrink-0 space-y-3">
        <div className="flex gap-3">
             <button 
                onClick={onClose} 
                className="flex-1 bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-500 hover:to-cyan-400 text-white font-bold py-3 px-6 rounded-xl transition-all shadow-lg hover:shadow-cyan-500/20 flex items-center justify-center gap-2 active:scale-[0.98]"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clipRule="evenodd" />
                </svg>
                Back
            </button>
            
            {/* Reset Profile Button */}
            {isResetConfirming ? (
                <div className="flex items-center gap-2 animate-fade-in">
                     <button 
                        onClick={onResetProfile}
                        className="bg-red-500 hover:bg-red-600 text-white font-bold py-3 px-4 rounded-xl shadow-lg text-sm flex items-center gap-1"
                     >
                        <span>🗑️</span> Confirm Delete?
                     </button>
                     <button 
                        onClick={() => setIsResetConfirming(false)}
                        className="bg-slate-700 hover:bg-slate-600 text-white font-bold py-3 px-4 rounded-xl shadow-lg text-sm"
                     >
                        Cancel
                     </button>
                </div>
            ) : (
                <button 
                    onClick={() => setIsResetConfirming(true)}
                    className="bg-slate-800/80 hover:bg-red-500/10 border border-red-500/30 hover:border-red-500 text-red-400 font-semibold py-3 px-4 rounded-xl transition-all text-sm flex items-center gap-2 shadow-sm hover:shadow-red-500/10"
                    title="Permanently Delete Account"
                >
                    <span className="text-lg">🗑️</span> Delete Account
                </button>
            )}
        </div>
        
        {/* Styled "Please Note" Section */}
        <div className="text-center relative pb-2">
             <div className="flex items-center justify-center gap-2 text-slate-500 text-xs uppercase font-bold tracking-widest mb-2 opacity-60">
                <span>—</span> <span>Please Note</span> <span>—</span>
             </div>
             <div className="inline-block bg-slate-800/50 rounded-full px-6 py-2 border border-slate-700 shadow-sm backdrop-blur-md">
                 <p className="text-sm text-cyan-300 font-medium flex items-center gap-2">
                    <span>👾</span> Rupees exist in-game only <span>👾</span>
                 </p>
             </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileDisplay;
