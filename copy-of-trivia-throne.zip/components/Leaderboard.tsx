
import React, { useMemo } from 'react';
import { UserProfile, Rank } from '../types';

interface LeaderboardProps {
  userProfile: UserProfile;
  onClose: () => void;
}

// Mock Data Generation
const generateMockLeaderboard = (user: UserProfile) => {
  const mockData = [
    { name: "TriviaGod", score: 1200000, rank: Rank.PRO, crown: true, isCurrentUser: false },
    { name: "QuizMaster99", score: 850000, rank: Rank.PRO, crown: true, isCurrentUser: false },
    { name: "SophieBrain", score: 600000, rank: Rank.PRO, crown: true, isCurrentUser: false },
    { name: "AlexTheGreat", score: 350000, rank: Rank.GRAND_MASTER, crown: true, isCurrentUser: false },
    { name: "KnowItAll", score: 150000, rank: Rank.GRAND_MASTER, crown: true, isCurrentUser: false },
    { name: "GeoWhiz", score: 95000, rank: Rank.HEROIC, crown: true, isCurrentUser: false },
    { name: "HistoryBuff", score: 75000, rank: Rank.MASTER, crown: true, isCurrentUser: false },
    { name: "ScienceNerd", score: 42000, rank: Rank.MASTER, crown: true, isCurrentUser: false },
    { name: "Rookie123", score: 15000, rank: Rank.PLATINUM, crown: false, isCurrentUser: false },
    { name: "GuestUser", score: 5000, rank: Rank.GOLD, crown: false, isCurrentUser: false },
  ];

  // Determine user rank info based on score (simplified logic similar to ProfileDisplay)
  let userRankName = Rank.IRON;
  if (user.totalPointsEarned >= 500000) userRankName = Rank.PRO;
  else if (user.totalPointsEarned >= 150000) userRankName = Rank.GRAND_MASTER;
  else if (user.totalPointsEarned >= 80000) userRankName = Rank.HEROIC;
  else if (user.totalPointsEarned >= 40000) userRankName = Rank.MASTER;
  else if (user.totalPointsEarned >= 20000) userRankName = Rank.DIAMOND;
  else if (user.totalPointsEarned >= 10000) userRankName = Rank.PLATINUM;
  else if (user.totalPointsEarned >= 4000) userRankName = Rank.GOLD;
  else if (user.totalPointsEarned >= 1500) userRankName = Rank.SILVER;
  else if (user.totalPointsEarned >= 500) userRankName = Rank.COPPER;

  const userEntry = {
    name: user.username || "Adventurer",
    score: user.totalPointsEarned,
    rank: userRankName,
    crown: user.totalPointsEarned >= 40000,
    isCurrentUser: true
  };

  // Merge and Sort
  const allEntries = [...mockData, userEntry].sort((a, b) => b.score - a.score);
  
  return allEntries;
};

const Leaderboard: React.FC<LeaderboardProps> = ({ userProfile, onClose }) => {
  const leaderboardData = useMemo(() => generateMockLeaderboard(userProfile), [userProfile]);

  return (
    <div className="w-full h-full flex flex-col animate-fade-in px-2 sm:px-4 pb-2 relative">
      <div className="flex-grow overflow-hidden flex flex-col min-h-0 bg-slate-900/30 rounded-xl border border-slate-800 shadow-inner mt-4">
        
        {/* Header Row */}
        <div className="grid grid-cols-12 gap-2 p-3 bg-slate-800/50 border-b border-slate-700 text-xs sm:text-sm font-bold text-slate-400 uppercase tracking-wider sticky top-0 z-10">
            <div className="col-span-2 text-center">#</div>
            <div className="col-span-6">Player</div>
            <div className="col-span-4 text-right">Score</div>
        </div>

        <div className="overflow-y-auto custom-scrollbar">
            {leaderboardData.map((entry, index) => (
                <div 
                    key={index} 
                    className={`grid grid-cols-12 gap-2 p-3 items-center border-b border-slate-800/50 transition-colors ${
                        entry.isCurrentUser 
                            ? 'bg-cyan-900/20 border-l-4 border-l-cyan-400' 
                            : 'hover:bg-slate-800/40'
                    }`}
                >
                    <div className="col-span-2 text-center font-bold text-slate-500 relative">
                        {index === 0 && <span className="text-2xl absolute -top-2 left-1/2 -translate-x-1/2">🥇</span>}
                        {index === 1 && <span className="text-xl absolute -top-1 left-1/2 -translate-x-1/2">🥈</span>}
                        {index === 2 && <span className="text-xl absolute -top-1 left-1/2 -translate-x-1/2">🥉</span>}
                        <span className={index < 3 ? 'opacity-0' : ''}>{index + 1}</span>
                    </div>
                    
                    <div className="col-span-6 flex items-center gap-2 overflow-hidden">
                        <div className="truncate font-semibold text-white text-sm sm:text-base">
                            {entry.name}
                        </div>
                        {entry.crown && (
                             <span className="text-lg sm:text-xl filter drop-shadow-md" title="Crown Holder">👑</span>
                        )}
                        {entry.isCurrentUser && (
                            <span className="bg-cyan-600 text-[10px] text-white px-1.5 py-0.5 rounded uppercase font-bold">You</span>
                        )}
                    </div>
                    
                    <div className="col-span-4 text-right font-mono font-bold text-cyan-400 text-sm sm:text-base">
                        {entry.score.toLocaleString()}
                    </div>
                </div>
            ))}
        </div>
      </div>

      {/* Footer Actions */}
      <div className="mt-4 flex-shrink-0">
        <button 
            onClick={onClose} 
            className="w-full bg-slate-700 hover:bg-slate-600 text-white font-bold py-3 px-6 rounded-xl transition-all shadow-lg flex items-center justify-center gap-2"
        >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clipRule="evenodd" />
            </svg>
            Back
        </button>
      </div>
    </div>
  );
};

export default Leaderboard;