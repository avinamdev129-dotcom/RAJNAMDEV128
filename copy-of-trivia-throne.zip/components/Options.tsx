
import React from 'react';

interface OptionsProps {
  options: string[];
  selectedAnswer: string | null;
  correctAnswer: string;
  onSelect: (option: string) => void;
  hiddenOptions?: string[];
}

const Options: React.FC<OptionsProps> = ({ options, selectedAnswer, correctAnswer, onSelect, hiddenOptions = [] }) => {
  const getButtonClass = (option: string) => {
    if (selectedAnswer) {
      if (option === correctAnswer) {
        return 'bg-green-500/20 border-green-500 text-green-400 cursor-not-allowed shadow-[0_0_20px_rgba(74,222,128,0.2)]';
      }
      if (option === selectedAnswer) {
        return 'bg-red-500/20 border-red-500 text-red-400 cursor-not-allowed';
      }
      return 'bg-slate-800/50 border-transparent cursor-not-allowed text-slate-500 opacity-40';
    }
    return 'bg-slate-700/50 hover:bg-slate-600/80 border-slate-600/50 hover:border-cyan-400/50 hover:shadow-lg hover:shadow-cyan-500/5 transform hover:-translate-y-0.5 active:translate-y-0';
  };

  return (
    <div className="grid grid-cols-1 gap-3 mt-4 lg:mt-0 w-full">
      {options.map((option, index) => {
        const isHidden = hiddenOptions.includes(option);
        const isSelected = selectedAnswer === option;
        const isCorrect = selectedAnswer && option === correctAnswer;
        const isWrong = isSelected && option !== correctAnswer;

        return (
            <button
            key={index}
            onClick={() => onSelect(option)}
            disabled={!!selectedAnswer || isHidden}
            className={`relative w-full text-left p-4 rounded-xl border-2 font-semibold text-white transition-all duration-200 flex items-center justify-between group ${getButtonClass(option)} ${isHidden ? 'opacity-0 pointer-events-none' : ''}`}
            >
            <div className="flex items-center z-10">
                <span className={`w-8 h-8 min-w-[2rem] rounded-lg flex items-center justify-center text-sm mr-4 font-bold transition-colors ${
                    isCorrect ? 'bg-green-500 text-white' : 
                    isWrong ? 'bg-red-500 text-white' : 
                    'bg-slate-800 text-slate-400 group-hover:bg-slate-700'
                }`}>
                    {String.fromCharCode(65 + index)}
                </span>
                <span className="text-sm sm:text-lg leading-tight">{option}</span>
            </div>
            
            {/* Status Icons */}
            {isCorrect && (
                 <div className="animate-pulse text-green-500">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                 </div>
            )}
            {isWrong && (
                 <div className="animate-shake text-red-500">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                    </svg>
                 </div>
            )}
            </button>
        );
      })}
    </div>
  );
};

export default Options;
