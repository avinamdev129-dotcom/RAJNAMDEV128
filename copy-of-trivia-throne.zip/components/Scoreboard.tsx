
import React, { useEffect, useState } from 'react';

interface ScoreboardProps {
  score: number;
  currentRound: number;
  totalRounds: number;
  timeLeft: number;
  maxTime?: number;
  streak?: number;
  hasCrown?: boolean;
}

const Scoreboard: React.FC<ScoreboardProps> = ({ score, currentRound, totalRounds, timeLeft, maxTime = 10, streak = 0, hasCrown = false }) => {
  const timerColor = timeLeft <= 3 ? 'bg-red-500 shadow-[0_0_15px_rgba(239,68,68,0.5)]' : timeLeft <= 6 ? 'bg-yellow-500' : 'bg-cyan-500';
  const percentage = (timeLeft / maxTime) * 100;
  
  // Rolling counter for score
  const [displayScore, setDisplayScore] = useState(score);

  useEffect(() => {
    let start = displayScore;
    const end = score;
    if (start === end) return;

    const totalDuration = 500; // ms
    const incrementTime = (totalDuration / Math.abs(end - start));
    
    const timer = setInterval(() => {
      start += 1 * Math.sign(end - start);
      setDisplayScore(start);
      if (start === end) clearInterval(timer);
    }, Math.max(incrementTime, 10));

    return () => clearInterval(timer);
  }, [score]);

  return (
    <div className="flex flex-col gap-2 mb-6 w-full">
        <div className="flex justify-between items-end text-lg px-1">
        <div className="font-semibold flex items-center gap-4">
            <div className="flex items-center gap-1 bg-slate-900/40 px-3 py-1 rounded-full border border-slate-700/50">
                Score: <span className="text-cyan-400 font-bold text-2xl ml-1 font-mono">{displayScore}</span>
                {hasCrown && (
                    <span title="Crown Holder" className="text-xl animate-[bounce_3s_infinite] filter drop-shadow-md cursor-help ml-1">👑</span>
                )}
            </div>
            {streak > 1 && (
                <div className="flex items-center gap-1 text-orange-400 animate-bounce">
                    <span className="text-xl">🔥</span>
                    <span className="font-black text-lg">{streak}</span>
                </div>
            )}
        </div>
        <div className="font-semibold text-slate-400 text-sm sm:text-base">
            Round <span className="text-white font-bold">{currentRound}</span> / {totalRounds}
        </div>
        </div>
        
        {/* Timer Bar */}
        <div className="w-full h-5 bg-slate-900/60 rounded-full overflow-hidden border border-slate-700 relative shadow-inner">
            <div 
                className={`h-full transition-all duration-1000 ease-linear ${timerColor}`} 
                style={{ width: `${percentage}%` }}
            ></div>
            <div className="absolute inset-0 flex items-center justify-center text-[10px] font-bold tracking-widest text-white shadow-sm uppercase">
                {timeLeft} seconds
            </div>
        </div>
    </div>
  );
};

export default Scoreboard;
