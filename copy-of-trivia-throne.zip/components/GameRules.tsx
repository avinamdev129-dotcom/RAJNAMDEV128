
import React from 'react';

interface GameRulesProps {
  onClose: () => void;
}

const GameRules: React.FC<GameRulesProps> = ({ onClose }) => {
  return (
    <div className="w-full h-full flex flex-col animate-fade-in px-2 sm:px-4 pb-2 relative text-left">
      <div className="flex-grow overflow-hidden flex flex-col min-h-0 bg-slate-900/30 rounded-xl border border-slate-800 shadow-inner mt-2">
        
        <div className="p-4 border-b border-slate-700/50 bg-slate-800/50">
            <h2 className="text-2xl font-bold text-cyan-400 flex items-center gap-2">
                <span>📜</span> Game Rules
            </h2>
            <p className="text-slate-400 text-sm">Master the mechanics to claim the throne.</p>
        </div>

        <div className="overflow-y-auto custom-scrollbar p-4 space-y-6">
            
            {/* Section: Basics */}
            <section>
                <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                    <span className="text-yellow-400">⚡</span> The Basics
                </h3>
                <div className="bg-slate-800/60 p-3 rounded-lg border border-slate-700/50 text-sm text-slate-300 leading-relaxed">
                    <p>Answer questions correctly before the timer runs out. The faster you answer, the more points you score. Be careful—wrong answers deduct points!</p>
                </div>
            </section>

            {/* Section: Difficulty & Scoring */}
            <section>
                <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                    <span className="text-green-400">🎯</span> Difficulty & Scoring
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="bg-slate-800/60 p-3 rounded-lg border border-green-500/20">
                        <p className="font-bold text-green-400 mb-1">Easy Mode</p>
                        <ul className="text-xs text-slate-300 space-y-1">
                            <li>• 10 Seconds</li>
                            <li>• Max 10 Points</li>
                            <li>• Beginner questions</li>
                        </ul>
                    </div>
                    <div className="bg-slate-800/60 p-3 rounded-lg border border-yellow-500/20">
                        <p className="font-bold text-yellow-400 mb-1">Medium Mode</p>
                        <ul className="text-xs text-slate-300 space-y-1">
                            <li>• 7 Seconds</li>
                            <li>• Max 20 Points</li>
                            <li>• Mixed difficulty</li>
                            <li>• <span className="text-cyan-300">Speed Bonus Active</span></li>
                        </ul>
                    </div>
                    <div className="bg-slate-800/60 p-3 rounded-lg border border-red-500/20">
                        <p className="font-bold text-red-400 mb-1">Hard Mode</p>
                        <ul className="text-xs text-slate-300 space-y-1">
                            <li>• 5 Seconds</li>
                            <li>• Max 30 Points</li>
                            <li>• Expert questions</li>
                            <li>• <span className="text-cyan-300">Speed Bonus Active</span></li>
                        </ul>
                    </div>
                </div>
            </section>

            {/* Section: Bonuses & Penalties */}
            <section>
                <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                    <span className="text-orange-400">🔥</span> Bonuses & Penalties
                </h3>
                <div className="bg-slate-800/60 rounded-lg border border-slate-700/50 overflow-hidden">
                    <table className="w-full text-sm text-left">
                        <tbody className="divide-y divide-slate-700/50">
                            <tr className="bg-slate-700/20">
                                <td className="p-3 text-cyan-300 font-bold">Speed Bonus</td>
                                <td className="p-3 text-slate-300">Answer in the first half of the timer (Medium/Hard) for <span className="font-bold text-white">1.5x Points</span>.</td>
                            </tr>
                            <tr>
                                <td className="p-3 text-orange-300 font-bold">Streak Bonus</td>
                                <td className="p-3 text-slate-300">Get answers right in a row to earn <span className="font-bold text-white">+2 pts</span> per streak count.</td>
                            </tr>
                            <tr className="bg-slate-700/20">
                                <td className="p-3 text-red-400 font-bold">Wrong Answer</td>
                                <td className="p-3 text-slate-300"><span className="font-bold text-red-400">-5 Points</span> penalty.</td>
                            </tr>
                             <tr>
                                <td className="p-3 text-yellow-400 font-bold">Skip</td>
                                <td className="p-3 text-slate-300"><span className="font-bold text-yellow-400">-2 Points</span> penalty.</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>
            
            {/* Section: Ranks & Currency */}
            <section>
                <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                    <span className="text-fuchsia-400">👑</span> Ranks & Rupees
                </h3>
                 <div className="bg-slate-800/60 p-3 rounded-lg border border-slate-700/50 text-sm text-slate-300 leading-relaxed space-y-2">
                    <p>
                        <span className="font-bold text-white">Total Score:</span> Accumulate points across all games to climb from <span className="text-slate-400">Iron</span> to <span className="text-fuchsia-400 font-bold">Pro Level</span>.
                    </p>
                    <p>
                        <span className="font-bold text-white">Rupees:</span> Earn rupees by reaching total score milestones. 
                        <br/>
                        <span className="text-xs text-slate-500 italic block mt-1 border-l-2 border-slate-600 pl-2">
                            Note: Rupees are an in-game score metric only and have no real-world value.
                        </span>
                    </p>
                </div>
            </section>

            {/* Section: Lifelines */}
            <section>
                <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                    <span className="text-indigo-400">🆘</span> Lifelines
                </h3>
                <div className="bg-slate-800/60 p-3 rounded-lg border border-slate-700/50 flex items-start gap-3">
                    <div className="bg-indigo-600 text-white text-xs font-bold px-2 py-1 rounded">50/50</div>
                    <p className="text-sm text-slate-300">
                        Removes 2 incorrect options. You can use this once per round!
                    </p>
                </div>
            </section>

        </div>
      </div>

      {/* Footer Actions */}
      <div className="mt-4 flex-shrink-0">
        <button 
            onClick={onClose} 
            className="w-full bg-slate-700 hover:bg-slate-600 text-white font-bold py-3 px-6 rounded-xl transition-all shadow-lg flex items-center justify-center gap-2"
        >
            Got it!
        </button>
      </div>
    </div>
  );
};

export default GameRules;
