
import React from 'react';
import { Difficulty } from '../types';

interface DifficultySelectorProps {
  onSelectDifficulty: (difficulty: Difficulty) => void;
}

const DifficultySelector: React.FC<DifficultySelectorProps> = ({ onSelectDifficulty }) => {
  return (
    <div className="text-center flex flex-col items-center justify-center h-full animate-fade-in">
      <h2 className="text-3xl font-bold text-cyan-400 mb-2">Choose Your Difficulty</h2>
      <p className="text-slate-300 text-lg mb-8">Test your knowledge at your own pace.</p>
      <div className="w-full max-w-xs space-y-4">
        <div>
          <button
            onClick={() => onSelectDifficulty(Difficulty.EASY)}
            className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-6 rounded-lg transition-all hover:scale-105 active:scale-95 duration-200 text-lg shadow-md"
          >
            Easy
          </button>
          <p className="text-slate-400 text-sm mt-2">A casual pace. 10 second timer.</p>
        </div>
        <div>
          <button
            onClick={() => onSelectDifficulty(Difficulty.MEDIUM)}
            className="w-full bg-yellow-500 hover:bg-yellow-600 text-slate-900 font-bold py-3 px-6 rounded-lg transition-all hover:scale-105 active:scale-95 duration-200 text-lg shadow-md"
          >
            Medium
          </button>
          <p className="text-slate-400 text-sm mt-2">A balanced challenge. 7 second timer.</p>
        </div>
        <div>
          <button
            onClick={() => onSelectDifficulty(Difficulty.HARD)}
            className="w-full bg-red-500 hover:bg-red-600 text-white font-bold py-3 px-6 rounded-lg transition-all hover:scale-105 active:scale-95 duration-200 text-lg shadow-md"
          >
            Hard
          </button>
          <p className="text-slate-400 text-sm mt-2">For the experts. 5 second timer.</p>
        </div>
      </div>
    </div>
  );
};

export default DifficultySelector;
