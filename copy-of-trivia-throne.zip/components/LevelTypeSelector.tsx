
import React, { useState, useEffect } from 'react';
import { LevelType } from '../types';

interface LevelTypeSelectorProps {
  onSelectLevelType: (levelType: LevelType) => void;
  onViewProfile: () => void;
  onViewLeaderboard: () => void;
  onViewRules: () => void;
  onStartDailyChallenge: () => void;
  onSpinWheel: () => void;
  isDailyChallengeCompleted: boolean;
}

const LevelTypeSelector: React.FC<LevelTypeSelectorProps> = ({ onSelectLevelType, onViewProfile, onViewLeaderboard, onViewRules, onStartDailyChallenge, onSpinWheel, isDailyChallengeCompleted }) => {
  const [showShareModal, setShowShareModal] = useState(false);
  const [gameUrl, setGameUrl] = useState('');
  const [copyStatus, setCopyStatus] = useState<'idle' | 'link'>('idle');
  const [isLocalhost, setIsLocalhost] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const url = new URL(window.location.href);
        url.hash = ''; 
        setGameUrl(url.toString());
        
        if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1' || window.location.protocol === 'file:') {
          setIsLocalhost(true);
        }
      } catch (e) {
        setGameUrl(window.location.href.split('#')[0]);
      }
    }

    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const categories = [
    { type: LevelType.FLAGS, color: 'bg-blue-500', hover: 'hover:bg-blue-600', text: 'text-white' },
    { type: LevelType.SCIENCE, color: 'bg-purple-500', hover: 'hover:bg-purple-600', text: 'text-white' },
    { type: LevelType.HISTORY, color: 'bg-orange-500', hover: 'hover:bg-orange-600', text: 'text-white' },
    { type: LevelType.WORLD_GEOGRAPHY, color: 'bg-teal-500', hover: 'hover:bg-teal-600', text: 'text-white' },
  ];

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(gameUrl);
      setCopyStatus('link');
      setTimeout(() => setCopyStatus('idle'), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const handleMainInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setDeferredPrompt(null);
      }
    } else {
      setShowShareModal(true);
    }
  };

  return (
    <div className="text-center flex flex-col items-center justify-center h-full animate-fade-in relative">
      <h2 className="text-3xl font-bold text-cyan-400 mb-2">Choose a Category</h2>
      <p className="text-slate-300 text-lg mb-8">Select a topic or take on the daily challenge!</p>
      <div className="w-full max-w-xs space-y-4">
        <button
          onClick={onStartDailyChallenge}
          disabled={isDailyChallengeCompleted}
          title={isDailyChallengeCompleted ? "You have already completed the daily challenge for today. Please come back tomorrow!" : "Play the Daily Challenge"}
          className={`w-full text-white font-bold py-3 px-6 rounded-lg transition-all text-lg shadow-md relative overflow-hidden group ${
            isDailyChallengeCompleted 
              ? 'bg-slate-700 text-slate-500 cursor-not-allowed' 
              : 'bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600'
          }`}
        >
          <span className={`absolute -inset-0.5 rounded-lg bg-gradient-to-r from-yellow-400 to-orange-500 blur opacity-0 group-hover:opacity-75 transition duration-500 ${isDailyChallengeCompleted && 'hidden'}`}></span>
          <span className="relative">
            {isDailyChallengeCompleted ? 'Come Back Tomorrow!' : 'Daily Challenge'}
          </span>
        </button>

        <hr className="border-slate-700" />

        {categories.map(category => (
           <button
            key={category.type}
            onClick={() => onSelectLevelType(category.type)}
            className={`w-full ${category.color} ${category.hover} ${category.text} font-bold py-3 px-6 rounded-lg transition-colors text-lg shadow-md`}
          >
            {category.type}
          </button>
        ))}
        
        {/* Action Bar */}
        <div className="grid grid-cols-4 gap-2 mt-4">
            <button
                onClick={onViewProfile}
                className="bg-slate-600 hover:bg-slate-500 text-cyan-400 font-bold py-3 px-2 rounded-lg transition-colors text-sm shadow-md border-2 border-slate-500 flex items-center justify-center gap-1 flex-col sm:flex-row"
                title="View Profile"
            >
                <span>👤</span> <span className="text-xs sm:text-sm">Profile</span>
            </button>
             <button
                onClick={onViewLeaderboard}
                className="bg-yellow-600/20 hover:bg-yellow-600/40 text-yellow-400 font-bold py-3 px-2 rounded-lg transition-colors text-sm shadow-md border-2 border-yellow-600/50 flex items-center justify-center gap-1 flex-col sm:flex-row"
                title="Leaderboard"
            >
                <span>🏆</span> <span className="text-xs sm:text-sm">Ranks</span>
            </button>
            <button
                onClick={onSpinWheel}
                className="bg-fuchsia-600/20 hover:bg-fuchsia-600/40 text-fuchsia-400 font-bold py-3 px-2 rounded-lg transition-colors text-sm shadow-md border-2 border-fuchsia-600/50 flex items-center justify-center gap-1 flex-col sm:flex-row"
                title="Lucky Spin"
            >
                <span>🎰</span> <span className="text-xs sm:text-sm">Spin</span>
            </button>
            <button
                onClick={onViewRules}
                className="bg-slate-700 hover:bg-slate-600 text-white font-bold py-3 px-2 rounded-lg transition-colors text-sm shadow-md border-2 border-slate-600 flex items-center justify-center gap-1 flex-col sm:flex-row"
                title="Game Rules"
            >
                <span>📜</span> <span className="text-xs sm:text-sm">Rules</span>
            </button>
        </div>
        
        <div className="mt-2">
            <button
            onClick={handleMainInstallClick}
            className={`w-full bg-slate-800 hover:bg-slate-700 text-green-400 hover:text-green-300 font-bold py-3 px-4 rounded-lg transition-colors text-sm shadow-md border border-green-500/30 hover:border-green-500/60 flex items-center justify-center gap-2 ${deferredPrompt ? 'animate-pulse ring-2 ring-green-500 ring-offset-2 ring-offset-slate-900' : ''}`}
            >
                {deferredPrompt ? '⬇️ Click to Install App' : '⬇️ Download App'}
            </button>
        </div>
      </div>

      {/* Simplified Install Modal */}
      {showShareModal && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-slate-900/95 backdrop-blur-md rounded-2xl p-2 animate-fade-in overflow-y-auto">
            <div className="bg-slate-800 border border-slate-700 p-6 rounded-2xl shadow-2xl w-full max-w-sm relative text-center">
                <button onClick={() => setShowShareModal(false)} className="absolute top-4 right-4 text-slate-400 hover:text-white bg-slate-900/50 rounded-full p-1 z-10">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>

                <div className="mb-4 text-cyan-400 text-5xl">📲</div>
                <h3 className="text-2xl font-bold text-white mb-2">Install App</h3>
                
                {isLocalhost ? (
                   <div className="bg-red-500/10 border border-red-500/30 p-3 rounded-xl mb-4 text-left">
                       <p className="text-red-400 font-bold text-sm mb-1">⚠️ Running on Computer</p>
                       <p className="text-slate-300 text-xs">
                         You cannot download the app to your phone yet because it is only running on this computer.
                       </p>
                       <div className="mt-3 pt-3 border-t border-red-500/20">
                          <p className="text-white text-xs font-bold mb-1">How to put it on your phone:</p>
                          <ol className="list-decimal pl-4 text-xs text-slate-400 space-y-1">
                              <li>Deploy this code to <b>Netlify</b> (easiest).</li>
                              <li>OR Build an APK file (Advanced).</li>
                          </ol>
                       </div>
                   </div>
                ) : (
                    <div className="space-y-4 text-left">
                         <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-700">
                            <p className="text-white font-bold mb-2">Option 1: Android</p>
                            <p className="text-slate-400 text-sm">
                                Tap the <span className="font-bold text-white">⋮ Menu</span> button in Chrome, then tap <span className="font-bold text-white">"Install App"</span> or "Add to Home Screen".
                            </p>
                         </div>
                         <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-700">
                            <p className="text-white font-bold mb-2">Option 2: iPhone (iOS)</p>
                            <p className="text-slate-400 text-sm">
                                Tap the <span className="font-bold text-white">Share</span> button in Safari, scroll down, and tap <span className="font-bold text-white">"Add to Home Screen"</span>.
                            </p>
                         </div>
                    </div>
                )}
                
                {!isLocalhost && (
                    <div className="mt-6 flex flex-col items-center">
                         <p className="text-xs text-slate-500 uppercase font-bold mb-2">Or Share Link</p>
                         <div className="flex gap-2">
                             <button onClick={handleCopy} className="bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold py-2 px-4 rounded-lg transition-colors">
                                {copyStatus === 'link' ? 'Copied!' : 'Copy Link'}
                             </button>
                         </div>
                    </div>
                )}
            </div>
        </div>
      )}
    </div>
  );
};

export default LevelTypeSelector;
