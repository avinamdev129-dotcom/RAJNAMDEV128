
import React, { useState, useCallback, useEffect, useRef } from 'react';
import type { QuizRound, UserProfile, Achievement } from './types';
import { GameState, Difficulty, LevelType } from './types';
import { fetchQuizData, fetchDailyChallengeData } from './services/geminiService';
import Scoreboard from './components/Scoreboard';
import FlagDisplay from './components/FlagDisplay';
import Options from './components/Options';
import GameResult from './components/GameResult';
import LoadingSpinner from './components/LoadingSpinner';
import DifficultySelector from './components/DifficultySelector';
import LevelTypeSelector from './components/LevelTypeSelector';
import QuestionDisplay from './components/QuestionDisplay';
import ProfileDisplay from './components/ProfileDisplay';
import Onboarding from './components/Onboarding';
import Leaderboard from './components/Leaderboard';
import AchievementNotification from './components/AchievementNotification';
import GameRules from './components/GameRules';
import SpinWheel from './components/SpinWheel';

const TOTAL_ROUNDS = 10;
const DAILY_CHALLENGE_ROUNDS = 5;
const DAILY_CHALLENGE_BONUS = 250;
const PENALTY_POINTS = 5;
const SKIP_PENALTY = 2;
const SPEED_BONUS_MULTIPLIER = 1.5;
const STREAK_BONUS = 2; // Extra points per streak count

const MAX_POINTS_CONFIG: Record<Difficulty, number> = {
  [Difficulty.EASY]: 10,
  [Difficulty.MEDIUM]: 20,
  [Difficulty.HARD]: 30,
};

const TIME_LIMITS: Record<Difficulty, number> = {
  [Difficulty.EASY]: 10,
  [Difficulty.MEDIUM]: 7,
  [Difficulty.HARD]: 5,
};

// --- ACHIEVEMENT DEFINITIONS ---
export const ACHIEVEMENTS: Achievement[] = [
  { id: 'first_win', title: 'First Steps', description: 'Complete your first quiz.', icon: '🏁', conditionDescription: 'Finish any quiz.' },
  { id: 'flag_bearer', title: 'Flag Bearer', description: 'Play a Flag Quiz.', icon: '🚩', conditionDescription: 'Play the Flags category.' },
  { id: 'speed_demon', title: 'Speed Demon', description: 'Answer in under 2 seconds.', icon: '⚡', conditionDescription: 'Answer correctly with > 80% time remaining.' },
  { id: 'on_fire', title: 'On Fire', description: 'Reach a streak of 5.', icon: '🔥', conditionDescription: 'Get 5 correct answers in a row.' },
  { id: 'perfectionist', title: 'Perfectionist', description: 'Get 100% accuracy.', icon: '🎯', conditionDescription: 'Score maximum points in a round (simplified check: all correct).' },
  { id: 'richie_rich', title: 'Richie Rich', description: 'Earn 1,000 Rupees.', icon: '💰', conditionDescription: 'Accumulate 1,000 Total Rupees.' },
  { id: 'high_roller', title: 'High Roller', description: 'Earn 50,000 Points.', icon: '🎩', conditionDescription: 'Reach 50,000 Total Points.' },
  { id: 'daily_devotion', title: 'Daily Devotion', description: 'Complete a Daily Challenge.', icon: '📅', conditionDescription: 'Finish the Daily Challenge mode.' },
];

const initialProfile: UserProfile = { 
  totalPointsEarned: 0, 
  totalRupees: 0, 
  highScores: {}, 
  lastDailyChallengeDate: undefined,
  username: undefined,
  unlockedAchievements: []
};

const getRupeesForTotalPoints = (points: number): number => {
  if (points >= 1000000) return 3000;
  if (points >= 800000) return 1350;
  if (points >= 500000) return 1000;
  if (points >= 300000) return 800;
  if (points >= 200000) return 700;
  if (points >= 150000) return 600;
  if (points >= 80000) return 300;
  if (points >= 40000) return 210;
  if (points >= 30000) return 180;
  if (points >= 20000) return 125;
  if (points >= 15000) return 110;
  if (points >= 10000) return 100;
  if (points >= 7000) return 70;
  if (points >= 6000) return 50;
  if (points >= 4000) return 35;
  if (points >= 2000) return 30;
  if (points >= 1500) return 25;
  if (points >= 1000) return 20;
  if (points >= 500) return 10;
  return 0;
};

const getTodayDateString = () => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
};


export default function App(): React.ReactElement {
  const [gameState, setGameState] = useState<GameState>(GameState.LOADING);
  const [levelType, setLevelType] = useState<LevelType | null>(null);
  const [quizRounds, setQuizRounds] = useState<QuizRound[]>([]);
  const [currentRoundIndex, setCurrentRoundIndex] = useState<number>(0);
  const [score, setScore] = useState<number>(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [difficulty, setDifficulty] = useState<Difficulty | null>(null);
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [pointsEarnedThisRound, setPointsEarnedThisRound] = useState<number>(0);
  const [userProfile, setUserProfile] = useState<UserProfile>(initialProfile);
  const [rupeesEarnedThisGame, setRupeesEarnedThisGame] = useState<number>(0);
  const [dailyChallengeBonus, setDailyChallengeBonus] = useState<number>(0);
  const [isNewHighScore, setIsNewHighScore] = useState<boolean>(false);
  
  // Refined Gameplay States
  const [streak, setStreak] = useState<number>(0);
  const [isFiftyFiftyUsed, setIsFiftyFiftyUsed] = useState<boolean>(false);
  const [hiddenOptions, setHiddenOptions] = useState<string[]>([]);
  
  // New states for progressive loading
  const [totalGameRounds, setTotalGameRounds] = useState<number>(0);
  const [isBackgroundLoading, setIsBackgroundLoading] = useState<boolean>(false);

  // Achievement State
  const [achievementQueue, setAchievementQueue] = useState<Achievement[]>([]);
  
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const isGameActiveRef = useRef<boolean>(false);
  const correctAnswersCountRef = useRef<number>(0); // Track correct answers for Perfectionist

  useEffect(() => {
    try {
      const savedProfile = localStorage.getItem('quizAppUserProfile');
      if (savedProfile) {
        const parsedProfile = JSON.parse(savedProfile);
        const profileWithFallback = { ...initialProfile, ...parsedProfile };
        if (!profileWithFallback.unlockedAchievements) {
            profileWithFallback.unlockedAchievements = [];
        }
        if (parsedProfile.totalRupees === undefined) {
             profileWithFallback.totalRupees = getRupeesForTotalPoints(profileWithFallback.totalPointsEarned);
        }
        setUserProfile(profileWithFallback);

        if (!profileWithFallback.username) {
           setGameState(GameState.ONBOARDING);
        } else {
           setGameState(GameState.SELECT_LEVEL_TYPE);
        }
      } else {
        // No profile saved
        setGameState(GameState.ONBOARDING);
      }
    } catch (err) {
      console.error("Failed to load user profile from localStorage", err);
      setUserProfile(initialProfile);
      setGameState(GameState.ONBOARDING);
    }
  }, []);

  const handleUpdateProfile = useCallback((updates: Partial<UserProfile>) => {
    setUserProfile(prev => {
      const newProfile = { ...prev, ...updates };
      try {
        localStorage.setItem('quizAppUserProfile', JSON.stringify(newProfile));
      } catch (err) {
        console.error("Failed to save user profile to localStorage", err);
      }
      return newProfile;
    });
  }, []);

  const handleResetProfile = useCallback(() => {
    // Clear local storage
    localStorage.removeItem('quizAppUserProfile');
    // Reset state
    setUserProfile(initialProfile);
    // Go to onboarding
    setGameState(GameState.ONBOARDING);
  }, []);

  const unlockAchievement = (id: string) => {
    if (userProfile.unlockedAchievements.includes(id)) return;

    const achievement = ACHIEVEMENTS.find(a => a.id === id);
    if (achievement) {
      setAchievementQueue(prev => [...prev, achievement]);
      handleUpdateProfile({ 
        unlockedAchievements: [...userProfile.unlockedAchievements, id] 
      });
    }
  };

  const handleSetUsername = (username: string) => {
    handleUpdateProfile({ username });
    setGameState(GameState.SELECT_LEVEL_TYPE);
  };

  // Check for Game Over Achievements
  useEffect(() => {
    if (gameState === GameState.GAME_OVER && levelType && difficulty) {
      
      const oldMilestoneRupees = getRupeesForTotalPoints(userProfile.totalPointsEarned);
      const newTotalPoints = userProfile.totalPointsEarned + score;
      const newMilestoneRupees = getRupeesForTotalPoints(newTotalPoints);
      
      const pointsBasedRupees = newMilestoneRupees - oldMilestoneRupees;
      
      const bonus = levelType === LevelType.DAILY_CHALLENGE ? DAILY_CHALLENGE_BONUS : 0;
      setDailyChallengeBonus(bonus);

      const totalRupeesEarnedThisGame = pointsBasedRupees + bonus;
      setRupeesEarnedThisGame(totalRupeesEarnedThisGame);

      const newTotalRupees = userProfile.totalRupees + totalRupeesEarnedThisGame;

      // --- ACHIEVEMENT CHECKS (GAME OVER) ---
      if (!userProfile.unlockedAchievements.includes('first_win')) unlockAchievement('first_win');
      if (levelType === LevelType.FLAGS) unlockAchievement('flag_bearer');
      if (levelType === LevelType.DAILY_CHALLENGE) unlockAchievement('daily_devotion');
      if (correctAnswersCountRef.current === quizRounds.length && quizRounds.length > 0) unlockAchievement('perfectionist');
      
      if (newTotalRupees >= 1000) unlockAchievement('richie_rich');
      if (newTotalPoints >= 50000) unlockAchievement('high_roller');
      // -------------------------------------

      const currentHighScoreEntry = userProfile.highScores[levelType]?.[difficulty];
      let currentHighScore = 0;
      
      if (typeof currentHighScoreEntry === 'number') {
        currentHighScore = currentHighScoreEntry;
      } else if (currentHighScoreEntry && typeof currentHighScoreEntry === 'object') {
        currentHighScore = currentHighScoreEntry.score;
      }

      const newHighScores: UserProfile['highScores'] = { ...userProfile.highScores };

      if (score > currentHighScore) {
        setIsNewHighScore(true);
        if (!newHighScores[levelType]) {
          newHighScores[levelType] = {};
        }
        newHighScores[levelType]![difficulty] = { score, date: getTodayDateString() };
      } else {
        setIsNewHighScore(false);
      }

      handleUpdateProfile({
        totalPointsEarned: newTotalPoints,
        totalRupees: newTotalRupees,
        highScores: newHighScores,
        lastDailyChallengeDate: levelType === LevelType.DAILY_CHALLENGE
          ? getTodayDateString()
          : userProfile.lastDailyChallengeDate,
      });
    }
  }, [gameState]);


  const clearTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  const handleSelectLevelType = (selectedLevelType: LevelType) => {
    setLevelType(selectedLevelType);
    setGameState(GameState.SELECT_DIFFICULTY);
  };
  
  const handleStartDailyChallenge = useCallback(async () => {
    setGameState(GameState.LOADING);
    isGameActiveRef.current = true;
    setSelectedAnswer(null);
    setScore(0);
    setStreak(0);
    setIsFiftyFiftyUsed(false);
    setHiddenOptions([]);
    setCurrentRoundIndex(0);
    setError(null);
    setLevelType(LevelType.DAILY_CHALLENGE);
    setDifficulty(Difficulty.MEDIUM);
    setTimeLeft(TIME_LIMITS[Difficulty.MEDIUM]);
    setRupeesEarnedThisGame(0);
    setDailyChallengeBonus(0);
    setTotalGameRounds(DAILY_CHALLENGE_ROUNDS);
    setIsBackgroundLoading(false);
    setIsNewHighScore(false);
    correctAnswersCountRef.current = 0;

    try {
      const data = await fetchDailyChallengeData();
      
      if (!isGameActiveRef.current) return; // Check if user cancelled

      setQuizRounds(data);
      if (data.length > 0) {
        setGameState(prev => prev === GameState.LOADING ? GameState.PLAYING : prev);
      } else {
        setError('Failed to load daily challenge data. Please try again.');
        setGameState(prev => prev === GameState.LOADING ? GameState.ERROR : prev);
      }
    } catch (err) {
      console.error(err);
      if (isGameActiveRef.current) {
        setError('An error occurred while fetching the daily challenge. Please try again later.');
        setGameState(prev => prev === GameState.LOADING ? GameState.ERROR : prev);
      }
    }
  }, []);

  const startGame = useCallback(async (selectedDifficulty: Difficulty) => {
    if (!levelType) return;
    setGameState(GameState.LOADING);
    isGameActiveRef.current = true;
    setSelectedAnswer(null);
    setScore(0);
    setStreak(0);
    setIsFiftyFiftyUsed(false);
    setHiddenOptions([]);
    setCurrentRoundIndex(0);
    setError(null);
    setDifficulty(selectedDifficulty);
    setTimeLeft(TIME_LIMITS[selectedDifficulty]);
    setRupeesEarnedThisGame(0);
    setDailyChallengeBonus(0);
    setTotalGameRounds(TOTAL_ROUNDS);
    setIsBackgroundLoading(false);
    setIsNewHighScore(false);
    correctAnswersCountRef.current = 0;

    try {
      // Parallel Loading Strategy
      // INCREASED BATCH SIZES to ensure we get enough unique questions even if duplicates are filtered out.
      // Target: 10 Rounds. Requesting: 2 + 8 + 8 = 18 Questions.
      const BATCH_1 = 2;
      const BATCH_2 = 8; 
      const BATCH_3 = 8;
      
      const fetchBatch1 = fetchQuizData(BATCH_1, selectedDifficulty, levelType);
      const fetchBatch2 = new Promise<QuizRound[]>(resolve => setTimeout(() => resolve(fetchQuizData(BATCH_2, selectedDifficulty, levelType)), 200));
      const fetchBatch3 = new Promise<QuizRound[]>(resolve => setTimeout(() => resolve(fetchQuizData(BATCH_3, selectedDifficulty, levelType)), 400));

      // 1. Wait for first batch to start playing
      const initialData = await fetchBatch1;
      
      if (!isGameActiveRef.current) return;

      setQuizRounds(initialData);
      
      if (initialData.length > 0) {
        setGameState(prev => prev === GameState.LOADING ? GameState.PLAYING : prev);
        setIsBackgroundLoading(true);
        
        const mergeData = (newData: QuizRound[]) => {
             setQuizRounds(current => {
                const existing = new Set(current.map(r => r.question + r.correctAnswer));
                const uniqueNew = newData.filter(r => !existing.has(r.question + r.correctAnswer));
                return [...current, ...uniqueNew];
             });
        };

        // Handle background batches as they arrive
        fetchBatch2.then(data => {
            if (isGameActiveRef.current) mergeData(data);
        }).catch(e => console.error("Background batch 2 failed", e));

        fetchBatch3.then(data => {
             if (isGameActiveRef.current) mergeData(data);
        }).catch(e => console.error("Background batch 3 failed", e));

        // Update loading state when all are settled
        Promise.allSettled([fetchBatch2, fetchBatch3]).finally(() => {
            if (isGameActiveRef.current) setIsBackgroundLoading(false);
        });

      } else {
        setError('Failed to load quiz data. Please try again.');
        setGameState(prev => prev === GameState.LOADING ? GameState.ERROR : prev);
      }
    } catch (err) {
      console.error(err);
      if (isGameActiveRef.current) {
        setError('An error occurred while fetching questions. Please try again later.');
        setGameState(prev => prev === GameState.LOADING ? GameState.ERROR : prev);
      }
    }
  }, [levelType]);

  useEffect(() => {
    if (gameState === GameState.PLAYING) {
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            clearTimer();
            setSelectedAnswer(''); 
            setPointsEarnedThisRound(0);
            setStreak(0); // Reset streak on timeout
            setGameState(GameState.ROUND_OVER);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return clearTimer;
  }, [gameState, currentRoundIndex]);


  const handleAnswerSelect = (option: string) => {
    if (gameState !== GameState.PLAYING || !difficulty) return;
    clearTimer();

    const correctAnswer = quizRounds[currentRoundIndex].correctAnswer;
    setSelectedAnswer(option);

    if (option === correctAnswer) {
      correctAnswersCountRef.current += 1;
      const maxPoints = MAX_POINTS_CONFIG[difficulty];
      const timeLimit = TIME_LIMITS[difficulty];
      
      let points = Math.ceil(maxPoints * (timeLeft / timeLimit));
      
      if (difficulty !== Difficulty.EASY && timeLeft > (timeLimit / 2)) {
          points = Math.ceil(points * SPEED_BONUS_MULTIPLIER);
      }

      if ((timeLimit - timeLeft) < 2) {
         unlockAchievement('speed_demon');
      }

      const currentStreakBonus = streak * STREAK_BONUS;
      points += currentStreakBonus;
      
      const newStreak = streak + 1;
      setScore(prev => prev + points);
      setPointsEarnedThisRound(points);
      setStreak(newStreak);

      if (newStreak >= 5) {
        unlockAchievement('on_fire');
      }

    } else {
      setScore(prev => Math.max(0, prev - PENALTY_POINTS));
      setPointsEarnedThisRound(-PENALTY_POINTS);
      setStreak(0);
    }
    setGameState(GameState.ROUND_OVER);
  };

  const handleSkip = () => {
    if (gameState !== GameState.PLAYING) return;
    clearTimer();
    setScore(prev => Math.max(0, prev - SKIP_PENALTY));
    setPointsEarnedThisRound(-SKIP_PENALTY);
    setSelectedAnswer('__SKIPPED__');
    setStreak(0);
    setGameState(GameState.ROUND_OVER);
  };

  const handleFiftyFifty = () => {
    if (gameState !== GameState.PLAYING || isFiftyFiftyUsed) return;
    
    const currentRound = quizRounds[currentRoundIndex];
    const incorrectOptions = currentRound.options.filter(opt => opt !== currentRound.correctAnswer);
    
    const shuffledIncorrect = [...incorrectOptions].sort(() => 0.5 - Math.random());
    const optionsToHide = shuffledIncorrect.slice(0, 2);
    
    setHiddenOptions(optionsToHide);
    setIsFiftyFiftyUsed(true);
  };

  const handleNextRound = () => {
    if (currentRoundIndex < quizRounds.length - 1) {
      setCurrentRoundIndex(prev => prev + 1);
      setSelectedAnswer(null);
      setHiddenOptions([]); 
      if (difficulty) {
        setTimeLeft(TIME_LIMITS[difficulty]);
      }
      setPointsEarnedThisRound(0);
      setGameState(GameState.PLAYING);
    } else if (!isBackgroundLoading) {
      // Only end game if we are not waiting for more questions
      setGameState(GameState.GAME_OVER);
    }
  };

  const handleRestart = () => {
    isGameActiveRef.current = false;
    setGameState(GameState.SELECT_LEVEL_TYPE);
  };

  const handleLeaveGame = () => {
    clearTimer();
    handleRestart();
  };

  const handleViewProfile = () => {
    setGameState(GameState.VIEW_PROFILE);
  };
  
  const handleViewLeaderboard = () => {
    setGameState(GameState.LEADERBOARD);
  };
  
  const handleViewRules = () => {
    setGameState(GameState.GAME_RULES);
  };
  
  const handleSpinWheel = () => {
    setGameState(GameState.SPIN_WHEEL);
  }

  const removeNotification = useCallback(() => {
    setAchievementQueue(prev => prev.slice(1));
  }, []);
  
  const currentRound = quizRounds[currentRoundIndex];

  const getHeader = () => {
    if (gameState === GameState.VIEW_PROFILE) {
      return { title: userProfile.username ? `Hello, ${userProfile.username}` : "Your Profile", subtitle: "Your progress and high scores." };
    }
    if (gameState === GameState.LEADERBOARD) {
      return { title: "Leaderboard", subtitle: "The greatest champions of Trivia Throne." };
    }
    if (gameState === GameState.GAME_RULES) {
      return { title: "How to Play", subtitle: "Everything you need to know." };
    }
    if (gameState === GameState.SPIN_WHEEL) {
        return { title: "Lucky Spin", subtitle: "Spend Rupees to win big!" };
    }
    if (gameState === GameState.ONBOARDING) {
      return { title: "Trivia Throne", subtitle: "Begin your journey" };
    }
    if (!levelType) return { title: "Trivia Throne", subtitle: "Select a category to begin your quest." };
    switch (levelType) {
      case LevelType.FLAGS:
        return { title: "Guess the Flag!", subtitle: "How well do you know the world's countries?" };
      case LevelType.SCIENCE:
        return { title: "Science Quiz", subtitle: "Test your scientific knowledge!" };
      case LevelType.HISTORY:
        return { title: "History Challenge", subtitle: "How well do you know the past?" };
      case LevelType.WORLD_GEOGRAPHY:
        return { title: "World Geography Quiz", subtitle: "Explore your knowledge of the globe." };
      case LevelType.DAILY_CHALLENGE:
        return { title: "Daily Challenge!", subtitle: "A special mixed quiz, just for today!" };
      default:
        return { title: "Trivia Throne", subtitle: "Test your knowledge!" };
    }
  };
  
  const headerContent = getHeader();
  
  const isDailyChallengeCompleted = userProfile.lastDailyChallengeDate === getTodayDateString();
  
  const hasCrown = userProfile.totalPointsEarned >= 40000;

  const renderGameResult = () => {
    if (!difficulty || !levelType) return null;
    return <GameResult 
      score={score} 
      totalRounds={quizRounds.length} 
      onRestart={handleRestart} 
      maxPointsPerRound={MAX_POINTS_CONFIG[difficulty]}
      rupeesEarned={rupeesEarnedThisGame}
      levelType={levelType}
      difficulty={difficulty}
      dailyChallengeBonus={dailyChallengeBonus}
      isNewHighScore={isNewHighScore}
    />;
  };

  const showCloseButton = gameState === GameState.PLAYING || 
                          gameState === GameState.ROUND_OVER || 
                          gameState === GameState.SELECT_DIFFICULTY ||
                          gameState === GameState.LOADING;

  const isLastAvailableRound = quizRounds.length > 0 && currentRoundIndex === quizRounds.length - 1;
  
  const showLoadingMore = isLastAvailableRound && isBackgroundLoading;

  const getResultMessage = () => {
    if (pointsEarnedThisRound > 0) {
        const timeLimit = difficulty ? TIME_LIMITS[difficulty] : 10;
        const isSpeedBonus = difficulty !== Difficulty.EASY && timeLeft > (timeLimit / 2);
        const streakBonus = streak > 1 ? ` (+${(streak - 1) * STREAK_BONUS} Streak)` : '';
        return { 
            text: `+${pointsEarnedThisRound} points!${isSpeedBonus ? ' (Speed Bonus!)' : ''}${streakBonus}`, 
            color: 'text-green-400' 
        };
    } else {
        if (selectedAnswer === '__SKIPPED__') {
            return { text: `Skipped! ${pointsEarnedThisRound} points`, color: 'text-yellow-400' };
        } else if (pointsEarnedThisRound < 0) {
            return { text: `Incorrect! ${pointsEarnedThisRound} points`, color: 'text-red-400' };
        } else if (selectedAnswer === '') {
            return { text: 'Time is up!', color: 'text-red-400' };
        } else {
            return { text: 'Incorrect!', color: 'text-red-400' };
        }
    }
  };
  
  const resultMessage = getResultMessage();
  const maxTime = difficulty ? TIME_LIMITS[difficulty] : 10;

  return (
    <main className="bg-gradient-to-br from-slate-900 to-slate-800 text-white min-h-screen flex flex-col items-center justify-center p-3 md:p-4 font-sans relative overflow-hidden animated-bg">
      {achievementQueue.length > 0 && (
        <AchievementNotification 
            key={achievementQueue[0].id} 
            achievement={achievementQueue[0]} 
            onClose={removeNotification} 
        />
      )}
      
      <div className="w-full max-w-2xl lg:max-w-5xl xl:max-w-6xl mx-auto relative z-10">
        <header className="text-center mb-4 md:mb-6">
          <h1 className="text-3xl md:text-5xl font-bold text-cyan-400 drop-shadow-md">{headerContent.title}</h1>
          <p className="text-slate-400 text-sm md:text-base mt-2">{headerContent.subtitle}</p>
        </header>

        <div className="bg-slate-800/70 backdrop-blur-sm border border-slate-700 p-4 sm:p-8 rounded-2xl shadow-2xl shadow-cyan-500/10 min-h-[450px] lg:min-h-[600px] flex flex-col justify-center card-glow relative transition-all duration-300">
          
          {gameState === GameState.ONBOARDING && <Onboarding onSetUsername={handleSetUsername} />}
          
          {gameState === GameState.SELECT_LEVEL_TYPE && (
            <LevelTypeSelector 
                onSelectLevelType={handleSelectLevelType} 
                onViewProfile={handleViewProfile} 
                onViewLeaderboard={handleViewLeaderboard}
                onViewRules={handleViewRules}
                onStartDailyChallenge={handleStartDailyChallenge} 
                onSpinWheel={handleSpinWheel}
                isDailyChallengeCompleted={isDailyChallengeCompleted} 
            />
          )}
          
          {gameState === GameState.VIEW_PROFILE && (
            <ProfileDisplay 
                userProfile={userProfile} 
                onClose={handleRestart} 
                onUpdateProfile={handleUpdateProfile} 
                onResetProfile={handleResetProfile}
            />
          )}
          {gameState === GameState.LEADERBOARD && <Leaderboard userProfile={userProfile} onClose={handleRestart} />}
          {gameState === GameState.GAME_RULES && <GameRules onClose={handleRestart} />}
          {gameState === GameState.SPIN_WHEEL && <SpinWheel userProfile={userProfile} onUpdateProfile={handleUpdateProfile} onClose={handleRestart} />}
          
          {gameState === GameState.SELECT_DIFFICULTY && <DifficultySelector onSelectDifficulty={startGame} />}
          {gameState === GameState.LOADING && <LoadingSpinner />}
          
          {(gameState === GameState.PLAYING || gameState === GameState.ROUND_OVER) && currentRound ? (
            <div className="animate-fade-in w-full">
              <Scoreboard
                score={score}
                currentRound={currentRoundIndex + 1}
                totalRounds={Math.max(quizRounds.length, totalGameRounds)}
                timeLeft={timeLeft}
                maxTime={maxTime}
                streak={streak}
                hasCrown={hasCrown}
              />
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-8 items-stretch mt-2 md:mt-4">
                <div className="flex flex-col items-center justify-center">
                  {levelType === LevelType.FLAGS && currentRound.flagEmoji ? (
                    <FlagDisplay flagEmoji={currentRound.flagEmoji} />
                  ) : (
                    <QuestionDisplay question={currentRound.question} />
                  )}
                </div>
                <div className="flex flex-col justify-center">
                  <Options
                    options={currentRound.options}
                    selectedAnswer={selectedAnswer}
                    correctAnswer={currentRound.correctAnswer}
                    onSelect={handleAnswerSelect}
                    hiddenOptions={hiddenOptions}
                  />
                  {gameState === GameState.PLAYING && (
                    <div className="grid grid-cols-2 gap-3 mt-4">
                        <button
                            onClick={handleFiftyFifty}
                            disabled={isFiftyFiftyUsed || hiddenOptions.length > 0}
                            className={`py-3 px-4 rounded-lg font-bold transition-all duration-200 text-sm shadow-lg flex items-center justify-center gap-2 ${isFiftyFiftyUsed ? 'bg-slate-800 text-slate-600 cursor-not-allowed border border-slate-700' : 'bg-indigo-600 hover:bg-indigo-500 text-white hover:scale-[1.02] border border-indigo-500'}`}
                        >
                             <span className="text-xs bg-white text-indigo-600 px-1.5 rounded-sm font-black">50/50</span> Lifeline
                        </button>
                        <button
                        onClick={handleSkip}
                        className="bg-slate-700 hover:bg-yellow-500/20 border border-slate-600 hover:border-yellow-500 text-slate-300 hover:text-yellow-400 font-semibold py-3 px-4 rounded-lg transition-all duration-200 text-sm"
                        >
                        Skip Question (-{SKIP_PENALTY} pts)
                        </button>
                    </div>
                  )}
                </div>
              </div>
              {gameState === GameState.ROUND_OVER && (
                <div className="text-center mt-4 md:mt-6 animate-fade-in bg-slate-900/50 p-4 rounded-xl border border-slate-700">
                  <p className={`font-bold text-2xl mb-4 ${resultMessage.color} drop-shadow-md`}>
                    {resultMessage.text}
                  </p>
                  <button
                    onClick={handleNextRound}
                    disabled={showLoadingMore}
                    className={`bg-cyan-500 hover:bg-cyan-600 text-slate-900 font-bold py-3 px-8 rounded-lg transition-all text-lg shadow-lg hover:shadow-cyan-500/20 hover:scale-105 active:scale-95 ${showLoadingMore ? 'opacity-75 cursor-wait' : ''}`}
                  >
                    {showLoadingMore 
                      ? 'Loading more questions...' 
                      : (isLastAvailableRound ? 'Finish Quiz' : 'Next Question ➜')
                    }
                  </button>
                </div>
              )}
            </div>
          ) : null}

          {gameState === GameState.GAME_OVER && renderGameResult()}
          
          {gameState === GameState.ERROR && error && (
            <div className="text-center text-red-400 animate-fade-in">
              <p className="text-xl mb-4">{error}</p>
              <button onClick={handleRestart} className="mt-4 bg-cyan-500 hover:bg-cyan-600 text-slate-900 font-bold py-3 px-6 rounded-lg">
                Try Again
              </button>
            </div>
          )}

          {showCloseButton && (
            <button
              type="button"
              onClick={handleLeaveGame}
              className="absolute top-3 right-3 sm:top-4 sm:right-4 z-50 p-2 text-slate-400 bg-slate-900/50 hover:bg-red-500/20 hover:text-red-400 rounded-full transition-all backdrop-blur-sm border border-slate-700/50 hover:border-red-500/50 shadow-sm"
              aria-label="Exit Game"
              title="Exit Game"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          )}

        </div>
      </div>
    </main>
  );
}
