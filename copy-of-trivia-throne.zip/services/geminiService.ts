
import { GoogleGenAI, Type } from "@google/genai";
import { Difficulty, LevelType, type QuizRound } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const flagQuizSchema = {
  type: Type.OBJECT,
  properties: {
    rounds: {
      type: Type.ARRAY,
      description: "An array of quiz rounds.",
      items: {
        type: Type.OBJECT,
        properties: {
          countryName: {
            type: Type.STRING,
            description: "The name of the country."
          },
          flagEmoji: {
            type: Type.STRING,
            description: "A single emoji character representing the country's flag."
          },
          options: {
            type: Type.ARRAY,
            description: "An array of country names, including the correct one, shuffled.",
            items: {
              type: Type.STRING
            }
          }
        },
        required: ["countryName", "flagEmoji", "options"]
      }
    }
  },
  required: ["rounds"]
};

const textQuizSchema = {
  type: Type.OBJECT,
  properties: {
    rounds: {
      type: Type.ARRAY,
      description: "An array of quiz rounds.",
      items: {
        type: Type.OBJECT,
        properties: {
          question: {
            type: Type.STRING,
            description: "The quiz question."
          },
          correctAnswer: {
            type: Type.STRING,
            description: "The correct answer to the question."
          },
          options: {
            type: Type.ARRAY,
            description: "An array of plausible answers, including the correct one, shuffled.",
            items: {
              type: Type.STRING
            }
          }
        },
        required: ["question", "correctAnswer", "options"]
      }
    }
  },
  required: ["rounds"]
};


const difficultyConfig: Record<Difficulty, { instruction: string; optionsCount: number }> = {
  [Difficulty.EASY]: {
    instruction: "for a beginner, from well-known and easily recognizable subjects in the category. For flags, use the 100 most well-known countries. The incorrect options should be distinct.",
    optionsCount: 4
  },
  [Difficulty.MEDIUM]: {
    instruction: "for an intermediate player, from a broad range of subjects, including both well-known and less common ones. For flags, incorrect options can be from the same continent.",
    optionsCount: 4
  },
  [Difficulty.HARD]: {
    instruction: "for an expert. For flags, use very obscure, remote, or small countries; incorrect options MUST be from the same geographical sub-region or have visually similar designs. For other topics, use obscure facts and ensure incorrect options are plausible and challenging.",
    optionsCount: 4
  },
};

// Helper to safely parse JSON from LLM output, handling markdown code blocks
const parseJSON = (text: string) => {
  try {
    // Remove markdown code blocks if present (e.g. ```json ... ```)
    const cleanedText = text.replace(/```json|```/g, '').trim();
    return JSON.parse(cleanedText);
  } catch (e) {
    console.error("JSON Parse Error on text:", text);
    throw e;
  }
};

// Helper to generate content with retry logic
const generateWithRetry = async (prompt: string, schema: any, retries = 1) => {
  for (let i = 0; i <= retries; i++) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: schema,
        },
      });
      return parseJSON(response.text);
    } catch (error) {
      if (i === retries) throw error;
      console.warn(`Attempt ${i + 1} failed. Retrying...`, error);
    }
  }
};


export const fetchQuizData = async (numberOfRounds: number, difficulty: Difficulty, levelType: LevelType): Promise<QuizRound[]> => {
  try {
    const config = difficultyConfig[difficulty];
    let quizData;

    if (levelType === LevelType.FLAGS) {
      const prompt = `Generate ${numberOfRounds} multiple-choice questions for a country flag guessing game.
      The difficulty should be ${difficulty}.
      For each question, provide the correct country name, its flag as a single emoji character, and ${config.optionsCount - 1} plausible but incorrect country name options.
      The selection of countries should be based on the following instruction: ${config.instruction}.
      Ensure the final options array contains exactly ${config.optionsCount} country names (1 correct, ${config.optionsCount - 1} incorrect) and is shuffled.`;

      const rawData = await generateWithRetry(prompt, flagQuizSchema);
      
      if (!rawData.rounds || rawData.rounds.length === 0) {
        throw new Error("API returned no quiz rounds.");
      }
      
      const mappedRounds: QuizRound[] = rawData.rounds.map((r: any) => ({
          question: `Which country's flag is this?`,
          correctAnswer: r.countryName,
          flagEmoji: r.flagEmoji,
          options: r.options
      }));

      quizData = mappedRounds;

    } else {
      const prompt = `Generate ${numberOfRounds} multiple-choice questions for a ${levelType} quiz.
      The difficulty should be ${difficulty}.
      For each question, provide the question, the correct answer, and ${config.optionsCount - 1} plausible but incorrect options.
      The selection of questions should be based on the following instruction: ${config.instruction}.
      Ensure the final options array contains exactly ${config.optionsCount} answers (1 correct, ${config.optionsCount - 1} incorrect) and is shuffled.`;

      const rawData = await generateWithRetry(prompt, textQuizSchema);

      if (!rawData.rounds || rawData.rounds.length === 0) {
        throw new Error("API returned no quiz rounds.");
      }
      
      quizData = rawData.rounds;
    }

    return quizData.filter((round: QuizRound) => 
        round.question &&
        round.correctAnswer &&
        round.options &&
        round.options.length === config.optionsCount &&
        round.options.includes(round.correctAnswer)
    );

  } catch (error) {
    console.error("Error fetching quiz data from Gemini API:", error);
    throw new Error("Failed to generate quiz data.");
  }
};


export const fetchDailyChallengeData = async (): Promise<QuizRound[]> => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const config = difficultyConfig[Difficulty.MEDIUM];
    
    const prompt = `Generate 5 challenging, multiple-choice questions for a mixed-category daily quiz for the date ${today}.
    This date is to ensure the questions are the same for all users today.
    The categories should be a mix of science, history, world geography, and general knowledge.
    The difficulty should be medium.
    For each question, provide the question, the correct answer, and ${config.optionsCount - 1} plausible but incorrect options.
    Ensure the final options array contains exactly ${config.optionsCount} answers and is shuffled.`;

    const rawData = await generateWithRetry(prompt, textQuizSchema);

    if (!rawData.rounds || rawData.rounds.length === 0) {
      throw new Error("API returned no quiz rounds for the daily challenge.");
    }
    
    return rawData.rounds.filter((round: QuizRound) => 
        round.question &&
        round.correctAnswer &&
        round.options &&
        round.options.length === config.optionsCount &&
        round.options.includes(round.correctAnswer)
    );
  } catch (error) {
    console.error("Error fetching daily challenge data from Gemini API:", error);
    throw new Error("Failed to generate daily challenge data.");
  }
};
